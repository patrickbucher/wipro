# px

`px`: the PEAX Command Line Client (Prototype)

## Setup

- Download the latest version of `px` for your platform (Mac OS, Linux,
  Windows) from the [Release](https://gitlab.peax.ch/peax3/px/-/releases) page.
- Unpack the archive, and move the `px` binary into your `$PATH`.
- Run `px version` to check if it works, and that you have the latest version
  installed.
- Run `px help` to explore the possibilities.

## Secure Key Store

### macOS

Keys are stored in _Keychain Access_.

### Linux

1. install [Seahorse](https://wiki.gnome.org/Apps/Seahorse) or a similar software
2. source `/etc/X11/xinit/xinitrc.d/50-systemd-user.sh`
3. create a password keyring called `login`

### Windows

Keys are stored in _Credential Manager_.

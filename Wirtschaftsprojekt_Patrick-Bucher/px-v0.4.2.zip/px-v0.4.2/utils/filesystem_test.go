package utils

import (
	"fmt"
	"io/ioutil"
	"math"
	"os"
	"strings"
	"testing"
)

func TestListDirectory(t *testing.T) {
	const (
		depth          = 3
		subFolders     = 4
		filesPerFolder = 5
	)
	tmpPath, err := createTestFolders(os.TempDir(), depth, subFolders, filesPerFolder)
	if err != nil {
		t.Errorf("get user home dir: %v", err)
	}
	defer os.RemoveAll(tmpPath)
	files, err := ListRecursively(tmpPath)
	if err != nil {
		t.Errorf("list home path %s: %v", tmpPath, err)
	}
	for _, filePath := range files {
		file, err := os.Open(filePath)
		if err != nil {
			t.Errorf("open %s: %v", filePath, err)
		}
		defer file.Close()
	}
	nFolders := math.Pow(float64(subFolders), float64(depth))
	expectedEntries := int(nFolders * filesPerFolder)
	gotEntries := len(files)
	if expectedEntries != gotEntries {
		t.Errorf("expected to list %d entries, got %d entries", expectedEntries, gotEntries)
	}
}

func createTestFolders(parentDir string, depth, subFolders, filesPerFolder int) (string, error) {
	childDir, err := ioutil.TempDir(parentDir, "folder")
	if err != nil {
		return "", fmt.Errorf("create temp dir: %v", err)
	}
	if err := createTempFileStructure(childDir, depth, subFolders, filesPerFolder); err != nil {
		return "", fmt.Errorf("create temp file structure under %s: %v", childDir, err)
	}
	return childDir, nil
}

func createTempFileStructure(parentDir string, depth, subFolders, filesPerFolder int) error {
	if depth > 0 {
		for folderNo := 0; folderNo < subFolders; folderNo++ {
			currentDir, err := ioutil.TempDir(parentDir, "folder")
			if err != nil {
				return fmt.Errorf("create temp dir: %v", err)
			}
			createTempFileStructure(currentDir, depth-1, subFolders, filesPerFolder)
		}
	} else {
		for fileNo := 0; fileNo < filesPerFolder; fileNo++ {
			file, err := ioutil.TempFile(parentDir, "file")
			if err != nil {
				return fmt.Errorf("create temp file: %v", err)
			}
			defer file.Close()
			file.Write([]byte("junk"))
		}
	}
	return nil
}

var splitCommonDistinctTests = []struct {
	paths    []string
	common   string
	distinct []string
}{
	{
		paths:    []string{},
		common:   "",
		distinct: []string{},
	},
	{
		paths: []string{
			"foo/bar/baz/bum",
			"foo/bar/qux/pam",
			"foo/bar/kaz/zak",
			"foo/bar/bim/bam",
			"foo/qux",
		},
		common: "foo",
		distinct: []string{
			"bar/baz/bum",
			"bar/qux/pam",
			"bar/kaz/zak",
			"bar/bim/bam",
			"qux",
		},
	},
	{
		paths: []string{
			"foo/bar/baz/bum",
			"foo/bar/baz/pam",
			"foo/bar/baz/zak",
			"foo/bar/baz/bam",
			"foo/bar/baz/pim",
		},
		common: "foo/bar/baz",
		distinct: []string{
			"bum",
			"pam",
			"zak",
			"bam",
			"pim",
		},
	},
	{
		paths: []string{
			"/home/johndoe/documents/taxes/2018/deductions/insurances.pdf",
			"/home/johndoe/documents/taxes/2018/deductions/donations.pdf",
			"/home/johndoe/documents/taxes/2018/wage-slips/work.pdf",
			"/home/johndoe/documents/taxes/2019/deductions/insurances.pdf",
			"/home/johndoe/documents/taxes/2019/wage-slips/work.pdf",
			"/home/johndoe/documents/taxes/2019/wage-slips/side-job.pdf",
		},
		common: "/home/johndoe/documents/taxes",
		distinct: []string{
			"2018/deductions/insurances.pdf",
			"2018/deductions/donations.pdf",
			"2018/wage-slips/work.pdf",
			"2019/deductions/insurances.pdf",
			"2019/wage-slips/work.pdf",
			"2019/wage-slips/side-job.pdf",
		},
	},
}

func TestSplitCommonDistinct(t *testing.T) {
	for _, test := range splitCommonDistinctTests {
		// make sure path separator also works on non-UNIX platforms
		sep := string(os.PathSeparator)
		paths := make([]string, 0)
		distincts := make([]string, 0)
		for _, path := range test.paths {
			paths = append(paths, strings.Replace(path, "/", sep, -1))
		}
		common := strings.Replace(test.common, "/", sep, -1)
		for _, distinct := range test.distinct {
			distincts = append(distincts, strings.Replace(distinct, "/", sep, -1))
		}
		gotCommon, gotDistinctMap := SplitCommonDistinct(paths)
		if gotCommon != common {
			t.Errorf("expected common part to be '%s', was '%s'", common, gotCommon)
		}
		if len(gotDistinctMap) != len(distincts) {
			t.Errorf("expected %d distinct elements, got %d", len(distincts), len(gotDistinctMap))
		}
		for originalPath, gotDistinct := range gotDistinctMap {
			contained := false
			for _, expectedDistinct := range distincts {
				if gotDistinct == expectedDistinct {
					contained = true
					break
				}
			}
			if !contained {
				t.Errorf("no distinct part was not split off from original path '%s'", originalPath)
			}
		}
	}
}

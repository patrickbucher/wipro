// +build !windows

package utils

import (
	"fmt"
	"syscall"

	"golang.org/x/crypto/ssh/terminal"
)

// InputPassword reads a password interactively from standard input in a safe
// way, i.e. using a SSH terminal.
func InputPassword(prompt string) (string, error) {
	fmt.Print(prompt)
	input, err := terminal.ReadPassword(int(syscall.Stdin))
	fmt.Println()
	if err != nil {
		return "", fmt.Errorf("reading password from terminal: %v", err)
	}
	return string(input), nil
}

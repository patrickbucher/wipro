// Package utils provides various utility functions for dealing with user input
// and directories.
package utils

import (
	"bufio"
	"encoding/json"
	"fmt"
	"image/color"
	"image/color/palette"
	"io/ioutil"
	"math/rand"
	"os"
	"path"
	"strings"
	"time"
)

func init() {
	rand.Seed(time.Now().Unix())
}

// FileMissing checks if the file indicated with path does not exists, and
// returns true if so. If the indicated file already exists, false is returned.
func FileMissing(path string) bool {
	_, err := os.Stat(path)
	return os.IsNotExist(err)
}

// ConsoleInput prints the given prompt to standard output via inputFunc, which
// is supposed to capture the user's input and return it as a string. The input
// string read from inputFunc and the error returned are returned from
// ConsoleInput, too. If no input was submitted, an error is returned.
func ConsoleInput(prompt string, inputFunc func(string) (string, error)) (string, error) {
	if input, err := inputFunc(prompt); err != nil {
		return "", fmt.Errorf("read from standard input: %v", err)
	} else if strings.TrimSpace(input) == "" {
		return "", fmt.Errorf("no valid input provided")
	} else {
		return strings.TrimSpace(input), nil
	}
}

// InputString is a simple input function that prints the given prompt to the
// standard output, reads a single line from standard input, and returns the
// string entered, or an error if reading the string failed.
func InputString(prompt string) (string, error) {
	fmt.Print(prompt)
	reader := bufio.NewReader(os.Stdin)
	input, err := reader.ReadString('\n')
	if err != nil {
		return "", err
	}
	return input, nil
}

// ReadFileFromHomeFolder reats the file named filename, which is located in
// the user's home folder, into memory and returns its content as a by slice,
// or an error if the process failed.
func ReadFileFromHomeFolder(filename string) ([]byte, error) {
	dotFilePath, err := GetHomeFolderPath(filename)
	if err != nil {
		return nil, fmt.Errorf("get dot file path for %s: %v", filename, err)
	}
	content, err := ioutil.ReadFile(dotFilePath)
	if err != nil {
		return nil, fmt.Errorf("read payload from %s: %v", dotFilePath, err)
	}
	return content, nil
}

// WriteJSONFileToHomeFolder writes the given payload as a JSON file with the
// given filename into the user's home folder, returning an error if the
// process failed.
func WriteJSONFileToHomeFolder(payload interface{}, filename string) error {
	data, err := json.MarshalIndent(payload, "", "\t")
	if err != nil {
		return fmt.Errorf("marshal JSON: %v", err)
	}
	homeFolderPath, err := GetHomeFolderPath(filename)
	if err != nil {
		return fmt.Errorf("get dot file path for %s: %v", filename, err)
	}
	if err := ioutil.WriteFile(homeFolderPath, data, 0644); err != nil {
		return fmt.Errorf("write payload to %s: %v", homeFolderPath, err)
	}
	return nil
}

// GetHomeFolderPath returns the absolute path for the current user's home
// folder, or an error, if the home folder path could not have been detected.
func GetHomeFolderPath(filename string) (string, error) {
	home, err := os.UserHomeDir()
	if err != nil {
		return "", fmt.Errorf("detecting user home dir: %v", err)
	}
	return path.Join(home, filename), nil
}

// PickRandomHexColour picks a random color from palette.Plan9 as a hex color
// code, such as "#cc8844".
func PickRandomHexColour() string {
	colorPalette := palette.WebSafe
	nColors := len(colorPalette)
	colorIndex := rand.Intn(nColors)
	colour := color.RGBAModel.Convert(colorPalette[colorIndex]).(color.RGBA)
	return fmt.Sprintf("#%.2x%.2x%.2x", colour.R, colour.G, colour.B)
}

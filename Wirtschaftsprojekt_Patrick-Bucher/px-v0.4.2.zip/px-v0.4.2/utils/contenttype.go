package utils

import (
	"fmt"
	"net/http"
	"os"
)

// DetectContentType sniffs the first 512 bytes from file, and tries to detect
// it's content type, which is returned.
func DetectContentType(filePath string) (string, error) {
	file, err := os.Open(filePath)
	if err != nil {
		return "", fmt.Errorf("unable to open file %s: %v", filePath, err)
	}
	defer file.Close()
	buf := make([]byte, 512)
	_, err = file.Read(buf)
	if err != nil {
		return "", fmt.Errorf("read from file: %v", err)
	}
	contentType := http.DetectContentType(buf)
	return contentType, nil
}

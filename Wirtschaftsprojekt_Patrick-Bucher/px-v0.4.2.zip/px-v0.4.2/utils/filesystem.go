package utils

import (
	"fmt"
	"io"
	"math"
	"os"
	"path/filepath"
	"strings"
)

// ReadFile opens the specified file, returns a ReadCloser to it, as well as
// its determined content type as a string. If one of the underlying operations
// (opening the file, determining the content type) does not work, an error is
// returned. The returned ReadCloser must be closed from the caller.
func ReadFile(filePath string) (io.ReadCloser, string, error) {
	contentType, err := DetectContentType(filePath)
	if err != nil {
		return nil, "", fmt.Errorf("determine content type of file %s: %v", filePath, err)
	}
	file, err := os.Open(filePath)
	if err != nil {
		return nil, "", fmt.Errorf("open file %s: %v", filePath, err)
	}
	return file, contentType, nil
}

// ListRecursively traverses through the entries under path recursively,
// returns a list of paths to the files contained, or an error, if path or one
// of it's subfolders cannot be read.
func ListRecursively(path string) ([]string, error) {
	filePaths := make([]string, 0)
	isReadable := func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return fmt.Errorf("check %s: %v", path, err)
		}
		fileInfo, err := os.Stat(path)
		if err != nil {
			return fmt.Errorf("stat %s: %v", path, err)
		}
		if fileInfo.IsDir() {
			// just do not add
			return nil
		}
		file, err := os.Open(path)
		if err != nil {
			return fmt.Errorf("open %s: %v", path, err)
		}
		defer file.Close()
		filePaths = append(filePaths, path)
		return nil
	}
	err := filepath.Walk(path, isReadable)
	if err != nil {
		return nil, fmt.Errorf("walking %s recursively: %v", path, err)
	}
	return filePaths, nil
}

// SplitCommonDistinct splits off the common part to all given paths from the
// beginning, and returns all paths separated into a common and a distinct
// part, returns the common path as a string, and the distinct parts as a map
// with the original path serving as the key, and the distinct part of the path
// as the value. For the following paths:
//
// /home/johndoe/documents/taxes/2017/deductions
// /home/johndoe/documents/taxes/2017/wage-slips
// /home/johndoe/documents/taxes/2018/deductions
// /home/johndoe/documents/taxes/2018/wage-slips
// /home/johndoe/documents/taxes/2019/deductions
// /home/johndoe/documents/taxes/2019/wage-slips
//
// The common part would be /home/johndoe/documents/taxes, and the individual
// parts would be 2017/deductions, 2017/wage-slipts, etc.
//
// If no common paths can be found, the returned common paths would be empty,
// and the returned distinct parts equal to the original paths.
func SplitCommonDistinct(paths []string) (string, map[string]string) {
	if len(paths) == 0 {
		return "", nil
	}
	pathSegments := make(map[string][]string, 0)
	distinctParts := make(map[string]string, 0)
	shortest := math.MaxInt32
	for _, path := range paths {
		segments := strings.Split(path, string(os.PathSeparator))
		pathSegments[path] = segments
		if length := len(segments); length < shortest {
			shortest = length
		}
	}
	commonParts := make([]string, 0)
	differenceFound := false
	differenceAtIndex := 0
	for i := 0; i < shortest && !differenceFound; i++ {
		candidate := ""
		for _, segments := range pathSegments {
			if candidate == "" {
				candidate = segments[i]
			} else if segments[i] != candidate {
				differenceFound = true
				differenceAtIndex = i
				break
			}
		}
		if !differenceFound {
			commonParts = append(commonParts, candidate)
		}
	}
	common := strings.Join(commonParts, string(os.PathSeparator))
	for path, segments := range pathSegments {
		distinctParts[path] = strings.Join(segments[differenceAtIndex:], string(os.PathSeparator))
	}
	return common, distinctParts
}

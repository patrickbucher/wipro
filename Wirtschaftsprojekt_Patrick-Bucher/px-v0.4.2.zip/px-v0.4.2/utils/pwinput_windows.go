package utils

import (
	"bufio"
	"fmt"
	"os"
)

// InputPassword reads a password interactively from standard input. Note that
// is a fallback implementation for Windows, which has issues with the SSH
// terminal used in the regular InputPassword function.
func InputPassword(prompt string) (string, error) {
	fmt.Print(prompt)
	reader := bufio.NewReader(os.Stdin)
	input, err := reader.ReadString('\n')
	if err != nil {
		return "", err
	}
	return input, nil
}

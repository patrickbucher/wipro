package utils

import "testing"

var contentTypeTests = map[string]string{
	"testdata/graph.gif": "image/gif",
	"testdata/graph.jpg": "image/jpeg",
	"testdata/graph.pdf": "application/pdf",
	"testdata/graph.png": "image/png",
	"testdata/graph.ps":  "application/postscript",
}

func TestDetectContentType(t *testing.T) {
	for filePath, expectedContentType := range contentTypeTests {
		gotContentType, err := DetectContentType(filePath)
		if err != nil {
			t.Errorf("detect content type: %v", err)
		}
		if gotContentType != expectedContentType {
			t.Errorf("for file '%s' expected content type '%s', got '%s'",
				filePath, expectedContentType, gotContentType)
		}
	}
}

// Package help contains help texts for the commands available in px.
package help

import (
	"bytes"
	"fmt"
	"px/env"
)

// Unspecified returns a help text about px and its commands.
func Unspecified(commands map[string]string) string {
	buf := bytes.NewBufferString(`
px ‒ the PEAX Command Line Client

This tool is supposed to make dealing with the PEAX API easier, especially the
dealing with OAuth 2.0 tokens.

The px tool is work in progress. If you work at PEAX, check out the repository
https://gitlab.peax.ch/peax3/px on GitLab.

Get in touch with the maintainer Patrick Bucher <patrick.bucher@peax.ch> if you
have questions, suggestions, or want to collaborate on px.

The following subcommands are supported at the moment:

`)

	for _, info := range commands {
		buf.WriteString(fmt.Sprintf("\t%s\n", info))
	}

	buf.WriteString(`
Run 'px help [subcommand]' to get help on the individual subcommands.

DISCLAIMER: The program deals with OAuth 2.0 tokens. Even though the operating
system's native key store is used to store sensitive tokens (run 'px help
login' for further information concerning the token handling), make sure to not
do anything with px you wouldn't do otherwise or with other tools.`)

	return buf.String()
}

// LoginInfo describes the login command.
const LoginInfo = "px login: log into a PEAX environment (fetch tokens)"

// Login returns a help text about the login command.
func Login() string {
	buf := bytes.NewBufferString(fmt.Sprintf("\n%s\n", LoginInfo))
	buf.WriteString(`
A login operation sends your credentials (username and password) to the PEAX
Identity Provider (IDP) and fetches a new token pair (Access Token and Refresh
Token). At no point does px store your password locally.

Username and Password can either be specified using the -u/-username and
-p/-password flag, or will otherwise be prompted interactively. If a second
factor (SMS, OTP) is required for the login, you will be interactively prompted
for that information, too.

The environment has to be specified using the -e/-env flag, and will be used as
your default environment for the next invocation of px, unless specified
otherwise using the other command's -e/-env flag. (Run 'px help env' and 'px
env -h' for further information on how to deal with different environments).

The following environments are supported:

`)

	for name, environment := range env.Environments {
		confidential := ""
		if environment.Confidential {
			confidential = "(confidential)"
		}
		buf.WriteString(fmt.Sprintf("\t%s %s\n", name, confidential))
	}

	buf.WriteString(`
For environments marked with (confidential), the token pair will be stored in
the operating system's native key store by default. For other environments, the
tokens will be stored in a file called '.px-tokens' in your $HOME directory.
This behaviour can be changed by providing the -u/-unsafe flag (to store the
tokens of confidential environments in .px-tokens) or the -s/-safe flag (to
store the tokens of not confidential environments in the native key store),
respectively.

There can be only one 'active login', i.e. stored token pair, for an
environment. If a login to an environment, for which already a token pair
exists, takes place, the existing token pair is overwritten.

It is possible to have a user login and an agent login for the same environment
at the same time.

Sample usage:

	px login -e dev -u john.doe@acme.org -p 'TopSecret'

Run 'px agent-login' for more information concerning the login for agents.

Run 'px login' -h to get information on the individual flags.`)

	return buf.String()
}

// LogoutInfo describes the logout command.
const LogoutInfo = "px logout: log out from a PEAX environment (delete tokens)"

// Logout returns a help text about the logout command.
func Logout() string {
	return fmt.Sprintf("\n%s\n", LogoutInfo) + `
A logout operation removes the token pair for either a specific environment (if
indicated with the -e/-env flag), or the token pairs of all environments (if
indicated with the -a/-all flag). The tokens are removed both from the
.px-tokens file and the native key store.

Sample usage:

	px logout -e dev
	px logout -a

Run 'px help login' to get more information on the token handling.

Run 'px logout -h' to get information on the individual flags.`
}

// AgentLoginInfo describes the agent-login command.
const AgentLoginInfo = "px agent-login: log into a PEAX environment as an agent (fetch tokens)"

// AgentLogin returns a help text about the agent-login command.
func AgentLogin() string {
	return fmt.Sprintf("\n%s\n", AgentLoginInfo) + `
This command is similar to 'px login', with the difference that it deals with
the Agent API. Instead of a username and a password, a client ID and a client
secret has to be provided, with the -u/-username and -p/-password flags,
though. There is no 2 Factor Authentication for agents.

It is possible to have an agent login and a user login for the same environment
at the same time.

Sample usage:

	px agent-login -e dev -u 'PEAX-agent-sydoc' -p '52ee2d8b-...'

Run 'px help login' to get more information on token handling, and how px deals
with different environments.

Run 'px agent-login -h' to get information on the individual flags.`
}

// AgentLogoutInfo describes the agent-logout command.
const AgentLogoutInfo = "px agent-logout: log out from a PEAX environment as an agent (delete tokens)"

// AgentLogout returns a help text about the agent-logout command.
func AgentLogout() string {
	return fmt.Sprintf("\n%s\n", AgentLogoutInfo) + `
This command is similar to 'px logout', with the difference that it deals with
the Agent API.

Sample usage:

	px agent-logout -e dev

Run 'px help logout' to get more information on the logout mechanism.

Run 'px agent-logout -h' to get information on the individual flags.`
}

// UploadInfo describes the upload command.
const UploadInfo = "px upload: upload documents to a PEAX environment"

// Upload returns a help text about the upload command.
func Upload() string {
	return fmt.Sprintf("\n%s\n", UploadInfo) + `
This command uploads a document (PDF or other formats), or a folder containing
documents (if the -r/-recursive flag is set), specified in an argument to PEAX.
Either the default environment (see 'px help env') or the environment specified
with -e/-env is used.

Sample usage:

	px upload document.pdf
	px upload -r my-documents

After a successful upload of a single document, a JSON payload indicating the
document details (including the generated UUID for the document entry) is
returned and printed to the standard output.

After a upload of a document folder, a JSON data structure reporting the
success/failure for every document contained in the folder is printed to the
standard output.

Meta data cannot be provided yet.

Run 'px upload -h' to get information on the individual flags.`
}

// GetInfo describes the get command.
const GetInfo = "px get: execute a HTTP GET request against a given resource"

// Get returns a help text about the get command.
func Get() string {
	return fmt.Sprintf("\n%s", GetInfo) + `
This command requires 1) an active login to an environment (default environment
or specified using the -e/-env flag), and 2) a full resource path to a
resource. The protocol and proxy URL is inferred from the environment.

Sample usage:

	px get 'document/api/v3/account/455.5462.5012.69/collection'

The returned payload is printed to the standard output.

Run 'px get -h' to get information on the individual flags.`
}

// EnvInfo describes the env command.
const EnvInfo = "px env: get or set the default environment for next commands"

// Env returns a help text about the env command.
func Env() string {
	return fmt.Sprintf("\n%s\n", EnvInfo) + `
This command can be used in two ways: 1) without any parameters, to display the
current default environment, and 2) with an environment parameter, to define
the default environment to be used for upcoming commands.

In order to define an environment as the default environment, a token pair for
the respective environment has to bee stored locally. After a login (see 'px
help login' for details), the default environment is set to the environment
just logged in.

For subsequent px commands, the default environment can be overwritten using
the -e/-env flag.

Sample usage:

	# print the current default environment
	px env 

	# set prod as the default environment
	px env prod

Run 'px env -h' to get information on the individual flags.`
}

// HelpInfo describes the help command.
const HelpInfo = "px help: show help on a specific command."

// Help returns a help text about the help command.
func Help() string {
	return fmt.Sprintf("\n%s\n", HelpInfo) + `
If used without any parameters, as you just did, this text is shown.

If used with a command parameter, the help text for the command specified is shown.

Sample usage:

	px help login

In order to get help on the flags of a command, run 'px [subcommand] -h'.`
}

// VersionInfo describes the version command.
const VersionInfo = "px version: show the current version of px."

// Version returns a help text about the version command.
func Version() string {
	return fmt.Sprintf("\n%s\n", VersionInfo) + `
The version is derived from the repositories latest tag. If the state of the
repository was not tagged during build time, the abbreviation of the latest
commit hash will be shown in the output.

Sample usage:

	px version

This command has no flags.`
}

// DeliverInfo describes the deliver command.
const DeliverInfo = "px deliver: deliver documents using the Agent API"

// Deliver returns a help text about the deliver command.
func Deliver() string {
	return fmt.Sprintf("\n%s\n", DeliverInfo) + `
The deliver command requires a valid agent token pair for the environment to be
used. This command is especially useful to deliver documents to any user on the
respective environment; unline the upload command for the User API, which only
uploads documents to the current user.

Since there is no default environment for the Agent API, the parameter -e/-env
must always be specified.

Sample usage:

	px deliver -e test -m meta.json document.pdf

Run 'px deliver -h' to get information on the individual flags.`
}

// PostInfo describes the post command.
const PostInfo = "px post: execute a POST request to create a new resource"

// Post returns a help text about the post command.
func Post() string {
	return fmt.Sprintf("\n%s\n", PostInfo) + `
This command requires 1) an active login to an environment (default environment
or specified using the -e/-env flag), 2) a path to the endpoint to create a new
resource, and 3) a JSON-payload specified with the -p/-payload flag. The
protocol and proxy URL is inferred from the environment.

Sample usage:

	px post -p tag.json profile/api/v3/profile/455.5462.5012.69/documenttag

With a payload tag.json like this:

	{
	  "name": "Taxes 2019",
	  "colour": "#ffec00"
	}

Run 'px post -h' to get information on the individual flags.`
}

// PutInfo describes the put command.
const PutInfo = "px put: execute a PUT request to create or replace a resource"

// Put returns a help text about the put command.
func Put() string {
	return fmt.Sprintf("\n%s\n", PutInfo) + `
This command requires 1) an active login to an environment (default environment
or specified using the -e/-env flag), 2) a path to the endpoint to create a new
or replace an existing resource, and 3) a payload (in any format) specified
with the -p/-payload flag. The protocol and proxy URL is inferred from the
environment.

Sample usage:

	px put -p profile-picture.png profile/api/v3/profile/455.5462.5012.69/picture/avatar

Run 'px put -h' to get information on the individual flags.`
}

// PatchInfo describes the patch command.
const PatchInfo = "px patch: execute a PATCH request to update a resource (partially)"

// Patch returns a help text about the patch command.
func Patch() string {
	return fmt.Sprintf("\n%s\n", PatchInfo) + `
This command requires 1) an active login to an environment (default environment
or specified using the -e/-env flag), 2) a patch to an endpoint to be updated
(partially), and 3) a payload JSON file according to RFC6902 (JSON Patch)
specified with the -p/-payload flag. The protocol and proxy URL is inferred
from the environment.

Sample usage:

	px patch -p document-patch.json document/api/v3/document/c5292712-260e-4038-8fbe-e6ea1853b84e

Run 'px patch -h' to get information on the individual flags.`
}

// DeleteInfo describes the delete command.
const DeleteInfo = "px delete: execute a PATCH request to remove a resource"

// Delete returns a help text about the delete command.
func Delete() string {
	return fmt.Sprintf("\n%s\n", DeleteInfo) + `
This command requires 1) an active login to an environment (default environment
or specified using the -e/-env flag), 2) an endpoint that accepts the DELETE
method. The protocol and proxy URL is inferred from the environment.

Sample usage:

	px delete profile/api/v3/profile/455.5462.5012.69/picture/avatar

Run 'px delete -h' to get information on the individual flags.`
}

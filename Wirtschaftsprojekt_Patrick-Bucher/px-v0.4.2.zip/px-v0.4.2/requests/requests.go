// Package requests contains functions that deal with different kinds of
// endpoints and HTTP verbs on the PEAX environments.
package requests

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"mime/multipart"
	"net/http"
	"os"
	"path/filepath"
	"px/env"
	"px/tokenstore"
	"px/utils"
	"strings"
	"sync"
)

// StatusCodeSecondFactorRequired is a special status code used to indicate
// after an authentication attempt that a second factor code is needed.
const StatusCodeSecondFactorRequired = 380

// RequestTokenPair requests a token pair at the given environment with the
// credentials provided. A secondFactorPrompt function is required, should the
// user be required to provide a second factor code. The fetched token pair is
// returned, or an error if the process failed.
func RequestTokenPair(peaxEnv *env.Environment, credentials Credentials,
	secondFactorPrompt func(string) (string, error)) (*tokenstore.TokenPair, error) {
	loginRequest, err := buildLoginRequest(peaxEnv, &credentials)
	if err != nil {
		return nil, fmt.Errorf("build login request: %v", err)
	}
	loginResponse, err := http.DefaultClient.Do(loginRequest)
	if err != nil {
		return nil, fmt.Errorf("do login request: %v", err)
	}

	if loginResponse.StatusCode == StatusCodeSecondFactorRequired {
		plainLoginResponse := loginResponse
		defer plainLoginResponse.Body.Close()
		loginResponse2FA, err := requestTokenPair2FA(plainLoginResponse, credentials, peaxEnv, secondFactorPrompt)
		if err != nil {
			return nil, fmt.Errorf("request token pair with 2FA: %v", err)
		}
		loginResponse = loginResponse2FA
	}
	defer loginResponse.Body.Close()
	statusCode := loginResponse.StatusCode
	if statusCode != http.StatusOK {
		return nil, fmt.Errorf("login failed with status %d %s", statusCode, http.StatusText(statusCode))
	}
	return extractTokenPair(loginResponse.Body, peaxEnv.Name, tokenstore.TokenTypeUser)
}

// RequestAgentTokenPair requests a token pair at the given environment with
// the given client credentials. No second factor authentication is used for
// client authentication. Either the fetched token pair or an error is
// returned.
func RequestAgentTokenPair(peaxEnv *env.Environment, credentials ClientCredentials) (*tokenstore.TokenPair, error) {
	loginRequest, err := buildLoginRequest(peaxEnv, &credentials)
	if err != nil {
		return nil, fmt.Errorf("build agent login request: %v", err)
	}
	loginResponse, err := http.DefaultClient.Do(loginRequest)
	if err != nil {
		return nil, fmt.Errorf("do agent login request: %v", err)
	}
	defer loginResponse.Body.Close()
	statusCode := loginResponse.StatusCode
	if statusCode != http.StatusOK {
		return nil, fmt.Errorf("agent login failed with status %d %s", statusCode, http.StatusText(statusCode))
	}
	return extractTokenPair(loginResponse.Body, peaxEnv.Name, tokenstore.TokenTypeAgent)
}

// FolderUploadResult represents the results of a recursive folder upload
// operation.
type FolderUploadResult struct {
	// Documents represents the lists of documents involved in the recursive
	// upload operation.
	Documents []DocumentUploadResult `json:"documents"`

	// Attempted is the number of documents attempted to upload (length of
	// Documents)
	Attempted int `json:"attempted"`

	// Uploaded is the number of documents that have been uploaded successfully
	// (length of Documents with Uploaded = true)
	Uploaded int `json:"uploaded"`

	// Failed is the number of documents that caused an error when uploading
	// (length of Documents with Uploaded = false)
	Failed int `json:"failed"`
}

// DocumentUploadResult represents the result of a document upload operation.
// Either DocumentId or ErrorMessage are set.
type DocumentUploadResult struct {
	// Uploaded is true if the document was uploaded successfully, false
	// otherwise.
	Uploaded bool `json:"uploaded"`

	// SourceDocument is the path to the document that has been attempted to
	// upload.
	SourceDocument string `json:"sourceDocument"`

	// DocumentId is the generated UUID of the document beeing uploaded
	// successfully.
	DocumentID string `json:"documentId,omitempty"`

	// ErrorMessage is the cause of a failed uplod operation.
	ErrorMessage string `json:"error,omitempty"`

	// Tags is a list of tags that has been assigned to the document after the upload.
	Tags []string `json:"tags,omitempty"`

	// TagErrorMessage is the cause of a failed tagging operation.
	TagErrorMessage string `json:"tag_error,omitempty"`
}

// UploadRecursively uploads the documents located under folderArg (relative
// path) to the given environment. The returned string represents a JSON
// payload rendered of FolderUploadResult. An error is returned, when the
// operation failed as a whole. If individual upload operations failed, even if
// all of them failed, a FolderUploadResult is returned nonetheless, reporting
// errors on individual operations.
func UploadRecursively(e *env.Environment, ts *tokenstore.TokenStore, folderArg string,
	verbose bool, tag bool) (string, error) {
	files, err := utils.ListRecursively(folderArg)
	if err != nil {
		return "", fmt.Errorf("list folder %s recursively: %v", folderArg, err)
	}
	total := len(files)
	if total == 0 {
		return "", fmt.Errorf("no documents found to upload in folder %s", folderArg)
	}
	common, distinct := utils.SplitCommonDistinct(files)
	tagsForFile := assignTagsToFile(common, distinct)
	tagsNeeded := extractUniqueTagNames(tagsForFile)
	err = createTagsIfMissing(tagsNeeded, e, ts)
	if err != nil {
		return "", fmt.Errorf("create missing tags: %v", err)
	}
	var wg sync.WaitGroup
	documentResults := make(chan DocumentUploadResult)
	const parallelTasks = 10
	tokens := make(chan struct{}, parallelTasks)
	for _, file := range files {
		wg.Add(1)
		go func(file string) {
			defer wg.Done()
			tokens <- struct{}{}
			res, err := uploadDocument(e, ts, file)
			<-tokens
			documentResult := interpretUploadResponse(res, err, file)
			if err == nil {
				// only tag if upload did work
				tagErr := addTags(documentResult.DocumentID, tagsForFile[file], e, ts)
				if tagErr != nil {
					documentResult.TagErrorMessage = fmt.Sprintf("%v", tagErr)
				} else {
					documentResult.Tags = tagsForFile[file]
				}
			}
			documentResults <- documentResult
		}(file)
	}
	folderResults := make(chan FolderUploadResult)
	go func() {
		folderResult := FolderUploadResult{
			Documents: make([]DocumentUploadResult, 0),
			Attempted: 0,
			Uploaded:  0,
			Failed:    0,
		}
		done := 0
		for documentResult := range documentResults {
			folderResult.Documents = append(folderResult.Documents, documentResult)
			folderResult.Attempted++
			if documentResult.Uploaded {
				folderResult.Uploaded++
			} else {
				folderResult.Failed++
			}
			done++
			if verbose {
				fmt.Fprintf(os.Stderr, "%d/%d\n", done, total)
			}
		}
		folderResults <- folderResult
	}()
	wg.Wait()
	close(documentResults)
	buf, err := json.Marshal(<-folderResults)
	if err != nil {
		return "", fmt.Errorf("marshal folder result: %v", err)
	}
	return string(buf), nil
}

func interpretUploadResponse(res *http.Response, err error, file string) DocumentUploadResult {
	type responsePayload struct {
		DocumentID string `json:"documentId"`
	}
	documentResult := DocumentUploadResult{
		Uploaded:        false,
		DocumentID:      "",
		SourceDocument:  file,
		ErrorMessage:    "",
		TagErrorMessage: "",
	}
	if err != nil {
		documentResult.ErrorMessage = fmt.Sprintf("%v", err)
	} else if res.StatusCode < 200 || res.StatusCode >= 300 {
		documentResult.ErrorMessage = fmt.Sprintf("HTTP response: %d %s", res.StatusCode,
			http.StatusText(res.StatusCode))
	} else {
		if payload, err := ioutil.ReadAll(res.Body); err != nil {
			documentResult.ErrorMessage = fmt.Sprintf("Read response body: %v", err)
		} else {
			var rp responsePayload
			if err = json.Unmarshal(payload, &rp); err != nil {
				documentResult.ErrorMessage = fmt.Sprintf("Get documentId from response: %v", err)
			} else {
				documentResult.Uploaded = true
				documentResult.DocumentID = rp.DocumentID
			}
		}
		res.Body.Close()
	}
	return documentResult
}

// UploadDocument uploads the file located under fileArg (relative path) to
// the given environment. In case of success, the returned payload containing
// the document's freshly generated UUID is returned; an error otherwise.
func UploadDocument(peaxEnv *env.Environment, tokenStore *tokenstore.TokenStore, fileArg string) (string, error) {
	res, err := uploadDocument(peaxEnv, tokenStore, fileArg)
	if err != nil {
		return "", fmt.Errorf("do upload request: %v", err)
	}
	defer res.Body.Close()
	if res.StatusCode != http.StatusOK {
		return "", fmt.Errorf("unexpected response to upload: %d %s", res.StatusCode, http.StatusText(res.StatusCode))
	}
	return bodyToString(res.Body)
}

// Deliver delivers the file located under fileArg to the PEAX user specified
// in the meta data (specified in the file under metadataArg, which must
// contain a receiverPeaxId field).
func Deliver(peaxEnv *env.Environment, tokenStore *tokenstore.TokenStore, fileArg, metadataArg string) (string, error) {
	generateDeliverRequest := func(accessToken string) (*http.Request, error) {
		deliveryEndpoint := fmt.Sprintf("%s/delivery/", peaxEnv.AgentAPI("document"))
		parts := map[string]string{
			"document": fileArg,
			"meta":     metadataArg,
		}
		body, contentType, err := multipartBody(parts)
		if err != nil {
			return nil, fmt.Errorf("create multipart body for parts %v: %v", parts, err)
		}
		req, err := http.NewRequest(http.MethodPost, deliveryEndpoint, body)
		if err != nil {
			return nil, fmt.Errorf("create POST request for %s: %v", deliveryEndpoint, err)
		}
		req.Header.Add("Authorization", "Bearer "+accessToken)
		req.Header.Add("Content-Type", contentType)
		return req, nil
	}
	res, err := doWithTokenRefresh(generateDeliverRequest, peaxEnv, tokenStore, tokenstore.TokenTypeAgent)
	if err != nil {
		return "", fmt.Errorf("perform POST request: %v", err)
	}
	defer res.Body.Close()
	if res.StatusCode != http.StatusOK {
		return "", fmt.Errorf("unexpected response to deliver: %d %s", res.StatusCode, http.StatusText(res.StatusCode))
	}
	return bodyToString(res.Body)
}

// Get performs a HTTP GET request to the given resource on the given
// environment. In case of success, the fetched payload is return, an error
// otherwise.
func Get(peaxEnv *env.Environment, tokenStore *tokenstore.TokenStore, resource string) (string, error) {
	generateGetRequest := func(accessToken string) (*http.Request, error) {
		getEndpoint := peaxEnv.ProxyURL(resource)
		req, err := http.NewRequest(http.MethodGet, getEndpoint, nil)
		if err != nil {
			return nil, fmt.Errorf("create GET request for %s: %v", getEndpoint, err)
		}
		req.Header.Add("Authorization", "Bearer "+accessToken)
		return req, nil
	}
	res, err := doWithTokenRefresh(generateGetRequest, peaxEnv, tokenStore, tokenstore.TokenTypeUser)
	if err != nil {
		return "", fmt.Errorf("perform GET request: %v", err)
	}
	defer res.Body.Close()
	if res.StatusCode != http.StatusOK {
		return "", fmt.Errorf("unexpected response to upload: %d %s", res.StatusCode, http.StatusText(res.StatusCode))
	}
	return bodyToString(res.Body)
}

// Post executes a POST request against the endpoint, using the payloadFile.
// The token pair is automatically refreshed transparently. Either the response
// payload (in case of success) or an error is returned.
func Post(peaxEnv *env.Environment, tokenStore *tokenstore.TokenStore, endpoint, payloadFile string) (string, error) {
	return requestWithJSON(peaxEnv, tokenStore, endpoint, payloadFile, http.MethodPost, ContentTypeJSON)
}

// Put executes a PUT request against the endpoint, using the payloadFile. The
// token pair is automatically refreshed transparently.
func Put(peaxEnv *env.Environment, tokenStore *tokenstore.TokenStore, endpoint, payloadFile string) error {
	_, err := requestWithJSON(peaxEnv, tokenStore, endpoint, payloadFile, http.MethodPut, "")
	if err != nil {
		return err
	}
	return nil
}

// Patch executes a PATCH request against the endpoint, using the payloadFile.
// The token pair is automatically refreshed transparently.
func Patch(peaxEnv *env.Environment, tokenStore *tokenstore.TokenStore, endpoint, payloadFile string) (string, error) {
	const contentType = "application/json-patch+json"
	return requestWithJSON(peaxEnv, tokenStore, endpoint, payloadFile, http.MethodPatch, contentType)
}

// Delete executes a DELETE request against the endpoint. The token pair is
// automatically refreshed transparently.
func Delete(peaxEnv *env.Environment, tokenStore *tokenstore.TokenStore, endpoint string) error {
	generateDeleteRequest := func(accessToken string) (*http.Request, error) {
		deleteEndpoint := peaxEnv.ProxyURL(endpoint)
		req, err := http.NewRequest(http.MethodDelete, deleteEndpoint, nil)
		if err != nil {
			return nil, fmt.Errorf("create DELETE request for %s: %v", deleteEndpoint, err)
		}
		req.Header.Add("Authorization", "Bearer "+accessToken)
		return req, nil
	}
	res, err := doWithTokenRefresh(generateDeleteRequest, peaxEnv, tokenStore, tokenstore.TokenTypeUser)
	if err != nil {
		return fmt.Errorf("perform DELETE request: %v", err)
	}
	defer res.Body.Close()
	if res.StatusCode < 200 || res.StatusCode >= 300 {
		return fmt.Errorf("unexpected response to delete: %d %s", res.StatusCode, http.StatusText(res.StatusCode))
	}
	return nil
}

func requestWithJSON(e *env.Environment, ts *tokenstore.TokenStore, endpoint, payload, method,
	contentType string) (string, error) {
	generateMethodRequest := func(accessToken string) (*http.Request, error) {
		req, err := generateRequest(e, endpoint, accessToken, payload, method, contentType)
		if err != nil {
			return nil, fmt.Errorf("generate %s request: %v", strings.ToUpper(method), err)
		}
		return req, nil
	}
	res, err := doWithTokenRefresh(generateMethodRequest, e, ts, tokenstore.TokenTypeUser)
	if err != nil {
		return "", fmt.Errorf("perform %s request: %v", strings.ToUpper(method), err)
	}
	defer res.Body.Close()
	if res.StatusCode < 200 || res.StatusCode >= 300 {
		return "", fmt.Errorf("unexpected response to %s request. %d %s",
			strings.ToUpper(method), res.StatusCode, http.StatusText(res.StatusCode))
	}
	return bodyToString(res.Body)
}

func generateRequest(e *env.Environment, endpoint, token, payload, method, contentType string) (*http.Request, error) {
	url := e.ProxyURL(endpoint)
	file, detectedContentType, err := utils.ReadFile(payload)
	if err != nil {
		return nil, fmt.Errorf("read file %s: %v", payload, err)
	}
	defer file.Close()
	buf := new(bytes.Buffer)
	if _, err := io.Copy(buf, file); err != nil {
		return nil, fmt.Errorf("copy from file %s: %v", payload, err)
	}
	req, err := http.NewRequest(method, url, buf)
	if err != nil {
		return nil, fmt.Errorf("create %s request to %s: %v", method, url, err)
	}
	if contentType == "" {
		contentType = detectedContentType
	}
	req.Header.Add("Authorization", "Bearer "+token)
	req.Header.Add("Content-Type", contentType)
	return req, nil
}

var tokenStoreSemaphore = make(chan struct{}, 1)

func doWithTokenRefresh(createRequest func(accessToken string) (*http.Request, error), e *env.Environment,
	ts *tokenstore.TokenStore, tokenType tokenstore.TokenType) (*http.Response, error) {
	tokenPair, err := ts.GetTokenPair(e.Name, tokenType)
	if err != nil {
		return nil, fmt.Errorf("get token pair from %s: %v", e.Name, err)
	}
	req, err := createRequest(tokenPair.AccessToken)
	if err != nil {
		return nil, fmt.Errorf("create request: %v", err)
	}
	res, err := http.DefaultClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("do request: %v", err)
	}
	if res.StatusCode == http.StatusUnauthorized {
		newTokenPair, err := renewAccessToken(e, tokenPair.RefreshToken, tokenPair.ClientID, tokenType)
		if err != nil {
			return nil, fmt.Errorf("renew token pair: %v", err)
		}
		newTokenPair.UseKeystore = tokenPair.UseKeystore
		tokenStoreSemaphore <- struct{}{}
		ts.SaveTokenPair(newTokenPair)
		<-tokenStoreSemaphore
		req, err = createRequest(newTokenPair.AccessToken)
		if err != nil {
			return nil, fmt.Errorf("create request (with refreshed access token): %v", err)
		}
		res, err = http.DefaultClient.Do(req)
		if err != nil {
			return nil, fmt.Errorf("retry request: %v", err)
		}
	}
	return res, nil
}

func renewAccessToken(peaxEnv *env.Environment, refreshToken, clientID string,
	tokenType tokenstore.TokenType) (*tokenstore.TokenPair, error) {
	req, err := buildTokenRefreshRequest(peaxEnv, refreshToken, clientID)
	if err != nil {
		return nil, fmt.Errorf("create request to renew access token: %v", err)
	}
	res, err := http.DefaultClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("perform renew access token request: %v", err)
	}
	defer res.Body.Close()
	if res.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("unexpected response when renewing access token: %d %s",
			res.StatusCode, http.StatusText(res.StatusCode))
	}
	tokenPair, err := extractTokenPair(res.Body, peaxEnv.Name, tokenType)
	if err != nil {
		return nil, fmt.Errorf("extract token pair from response: %v", err)
	}
	return tokenPair, nil
}

func requestTokenPair2FA(firstResponse *http.Response, credentials Credentials,
	peaxEnv *env.Environment, prompt func(string) (string, error)) (*http.Response, error) {
	challengePayload, err := ioutil.ReadAll(firstResponse.Body)
	if err != nil {
		return nil, fmt.Errorf("read payload from response body: %v", err)
	}
	var challenge Response2FAChallenge
	if err := json.Unmarshal(challengePayload, &challenge); err != nil {
		return nil, fmt.Errorf("unmarshal '%s' from challenge payload: %v", string(challengePayload), err)
	}

	secondFactorInput, err := prompt(string(challenge.SecondFactor))
	if err != nil {
		return nil, fmt.Errorf("promping for second factor: %s", err)
	}

	secondFactorPayload := Credentials2FA{credentials, challenge.SecondFactor, secondFactorInput}
	loginRequest, err := buildLoginRequest2FA(peaxEnv, secondFactorPayload)
	if err != nil {
		return nil, fmt.Errorf("building 2FA request: %v", err)
	}
	login2FAResponse, err := http.DefaultClient.Do(loginRequest)
	if err != nil {
		return nil, fmt.Errorf("do 2FA login request: %v", err)
	}
	return login2FAResponse, nil
}

func buildLoginRequest(env *env.Environment, credentials FormDataURLEncoded) (*http.Request, error) {
	payload := credentials.ToFormDataURLEncoded()
	req, err := http.NewRequest(http.MethodPost, env.TokenEndpoint(), strings.NewReader(payload))
	if err != nil {
		return nil, fmt.Errorf("create login request: %v", err)
	}
	req.Header.Add("Content-Type", ContentTypeForm)
	req.Header.Add("Accept", ContentTypeJSON)
	return req, nil
}

func buildLoginRequest2FA(env *env.Environment, credentials Credentials2FA) (*http.Request, error) {
	payload := credentials.ToFormDataURLEncoded2FA()
	req, err := http.NewRequest(http.MethodPost, env.TokenEndpoint(), strings.NewReader(payload))
	if err != nil {
		return nil, fmt.Errorf("create login request with 2FA: %v", err)
	}
	req.Header.Add("Content-Type", ContentTypeForm)
	req.Header.Add("Accept", ContentTypeJSON)
	return req, nil
}

func buildTokenRefreshRequest(env *env.Environment, refreshToken string, clientID string) (*http.Request, error) {
	payload := fmt.Sprintf("grant_type=refresh_token&refresh_token=%s&client_id=%s", refreshToken, clientID)
	req, err := http.NewRequest(http.MethodPost, env.TokenEndpoint(), strings.NewReader(payload))
	if err != nil {
		return nil, fmt.Errorf("create token refresh request: %v", err)
	}
	req.Header.Add("Content-Type", ContentTypeForm)
	req.Header.Add("Accept", ContentTypeJSON)
	return req, nil
}

func bodyWithFormFile(filePath, formField string) (*bytes.Buffer, string, error) {
	body := new(bytes.Buffer)
	writer := multipart.NewWriter(body)

	if err := addFormFile(formField, filePath, writer); err != nil {
		return nil, "", fmt.Errorf("add file '%s' as field %s to form: %v", formField, filePath, err)
	}
	if err := writer.Close(); err != nil {
		return nil, "", fmt.Errorf("close multipart writer: %v", err)
	}
	return body, writer.FormDataContentType(), nil
}

func multipartBody(parts map[string]string) (*bytes.Buffer, string, error) {
	body := new(bytes.Buffer)
	writer := multipart.NewWriter(body)
	for field, file := range parts {
		err := addFormFile(field, file, writer)
		if err != nil {
			return nil, "", fmt.Errorf("add file '%s' as field %s to form: %v", field, file, err)
		}
	}
	if err := writer.Close(); err != nil {
		return nil, "", fmt.Errorf("close multipart writer: %v", err)
	}
	return body, writer.FormDataContentType(), nil
}

func addFormFile(field, filePath string, writer *multipart.Writer) error {
	file, err := os.Open(filePath)
	if err != nil {
		return fmt.Errorf("open file '%s': %v", filePath, err)
	}
	defer file.Close()
	part, err := writer.CreateFormFile(field, filepath.Base(file.Name()))
	if err != nil {
		return fmt.Errorf("create form file for '%s': %v", filePath, err)
	}
	if _, err := io.Copy(part, file); err != nil {
		return fmt.Errorf("copy file '%s' to form: %v", filePath, err)
	}
	return nil
}

func extractTokenPair(body io.ReadCloser, environment string, tokenType tokenstore.TokenType) (*tokenstore.TokenPair,
	error) {
	var tokenResponse tokenstore.TokenResponse
	bodyBytes, err := ioutil.ReadAll(body)
	if err != nil {
		return nil, fmt.Errorf("unable to read body bytes from response: %v", err)
	}
	if err := json.Unmarshal(bodyBytes, &tokenResponse); err != nil {
		return nil, fmt.Errorf("unmarshal token response: %v", err)
	}
	tokenPair, err := tokenstore.FromResponse(&tokenResponse, environment, tokenType)
	if err != nil {
		return nil, fmt.Errorf("convert token response to token pair: %v", err)
	}
	return tokenPair, nil
}

func bodyToString(body io.ReadCloser) (string, error) {
	buf := bytes.NewBufferString("")
	_, err := io.Copy(buf, body)
	if err != nil {
		return "", fmt.Errorf("reading from response body: %v", err)
	}
	return buf.String(), nil
}

func uploadDocument(e *env.Environment, ts *tokenstore.TokenStore, filePath string) (*http.Response, error) {
	tp, err := ts.GetTokenPair(e.Name, tokenstore.TokenTypeUser)
	if err != nil {
		return nil, fmt.Errorf("get token pair for env %s: %v", e.Name, err)
	}
	generateUploadRequest := func(accessToken string) (*http.Request, error) {
		uploadEndpoint := fmt.Sprintf("%s/account/%s/collection/upload", e.DocumentAPI(), tp.PeaxID)
		body, contentType, err := bodyWithFormFile(filePath, "document")
		if err != nil {
			return nil, fmt.Errorf("create document body for file %s: %v", filePath, err)
		}
		req, err := http.NewRequest(http.MethodPost, uploadEndpoint, body)
		if err != nil {
			return nil, fmt.Errorf("create upload request for endpoint %s: %v", uploadEndpoint, err)
		}
		req.Header.Add("Content-Type", contentType)
		req.Header.Add("Authorization", "Bearer "+accessToken)
		return req, nil
	}
	return doWithTokenRefresh(generateUploadRequest, e, ts, tokenstore.TokenTypeUser)
}

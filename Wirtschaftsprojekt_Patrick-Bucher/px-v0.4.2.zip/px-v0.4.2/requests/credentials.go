package requests

import (
	"fmt"
	"net/url"
)

// FormDataURLEncoded is an interface satisfied by any type that allows for
// conversions to URL encoded form data using the ToFormDataURLEncoded
// function.
type FormDataURLEncoded interface {
	// ToFormDataURLEncoded converts the underlying data structure to a URL
	// encoded HTML form.
	ToFormDataURLEncoded() string
}

// Credentials represents the data needed to login, i.e. to fetch a token pair.
type Credentials struct {
	Username  string
	Password  string
	GrantType string
	ClientID  string
}

// ToFormDataURLEncoded encodes the credentials as a URL encoded form data
// string.
func (c *Credentials) ToFormDataURLEncoded() string {
	user := url.QueryEscape(c.Username)
	pass := url.QueryEscape(c.Password)
	grant := url.QueryEscape(c.GrantType)
	client := url.QueryEscape(c.ClientID)
	return fmt.Sprintf("username=%s&password=%s&grant_type=%s&client_id=%s", user, pass, grant, client)
}

// SecondFactorOption is a string type to discern different options for
// two-factor authentication.
type SecondFactorOption string

const (
	// SecondFactorSMS is the code for SMS-bases two-factor authentication.
	SecondFactorSMS SecondFactorOption = "sms"

	// SecondFactorOTP is the code for two-factor authentication based on a
	// time-based one-time password.
	SecondFactorOTP SecondFactorOption = "totp"

	// ContentTypeForm is the content type used to submit URL encoded forms.
	ContentTypeForm = "application/x-www-form-urlencoded"

	// ContentTypeJSON is the content type used to request and/or send JSON
	// payloads.
	ContentTypeJSON = "application/json"
)

// Response2FAChallenge is the payload sent back indicating that a second
// factor is needed in order to authenticate the user. The payload indicates
// with method is to be used.
type Response2FAChallenge struct {
	// SecondFactor describes the second factor (SMS or TOTP) to be used for
	// the two-factor authentication.
	SecondFactor SecondFactorOption `json:"challenge"`
}

// Credentials2FA is an addition to Credentials, which also contains the type
// (SMS/TOTP) and the verification code for a two-factor authentication.
type Credentials2FA struct {
	Credentials
	SecondFactor     SecondFactorOption
	SecondFactorCode string
}

// ToFormDataURLEncoded2FA encodes the two-factor authentication payload as URL
// encoded form data.
func (c *Credentials2FA) ToFormDataURLEncoded2FA() string {
	return fmt.Sprintf("%s&%s=%s", c.ToFormDataURLEncoded(), c.SecondFactor, c.SecondFactorCode)
}

// ClientCredentials describes the credentials for client-based authentication,
// which is used for the Agent API.
type ClientCredentials struct {
	ClientID     string
	ClientSecret string
	GrantType    string
}

// ToFormDataURLEncoded encodes the credentials as a URL encoded form data
// string.
func (c *ClientCredentials) ToFormDataURLEncoded() string {
	id := url.QueryEscape(c.ClientID)
	secret := url.QueryEscape(c.ClientSecret)
	grant := url.QueryEscape(c.GrantType)
	return fmt.Sprintf("client_id=%s&client_secret=%s&grant_type=%s", id, secret, grant)
}

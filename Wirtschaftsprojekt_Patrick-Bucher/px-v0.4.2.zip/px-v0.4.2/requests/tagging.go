package requests

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"os"
	"px/env"
	"px/tokenstore"
	"px/utils"
	"strings"
)

const (
	tagResourcePattern      = "profile/api/v3/profile/%s/documenttag"
	documentResourcePattern = "document/api/v3/document/%s"
)

func assignTagsToFile(common string, distinct map[string]string) map[string][]string {
	tagsForFile := make(map[string][]string, 0)
	sep := string(os.PathSeparator)

	// from the common part, use the last segment (containing folder)
	commonSegments := strings.Split(common, sep)
	if nCommonSegments := len(commonSegments); nCommonSegments > 0 {
		commonSegment := commonSegments[nCommonSegments-1]
		for file := range distinct {
			fileTags := make([]string, 0)
			fileTags = append(fileTags, commonSegment)
			tagsForFile[file] = fileTags
		}
	}

	// from the distinct part, use all segments except the last (document file)
	for file, distinctPath := range distinct {
		distinctSegments := strings.Split(distinctPath, sep)
		nDistinctSegments := len(distinctSegments)
		for _, distinctSegment := range distinctSegments[:nDistinctSegments-1] {
			tagsForFile[file] = append(tagsForFile[file], distinctSegment)
		}
	}

	return tagsForFile
}

func extractUniqueTagNames(tagsForFile map[string][]string) []string {
	tagNames := make([]string, 0)
	tagNameSet := make(map[string]struct{}, 0)
	for _, tagList := range tagsForFile {
		for _, tag := range tagList {
			tagNameSet[tag] = struct{}{}
		}
	}
	for tagName := range tagNameSet {
		tagNames = append(tagNames, tagName)
	}
	return tagNames
}

func createTagsIfMissing(tags []string, e *env.Environment, ts *tokenstore.TokenStore) error {
	type documenttagPayload struct {
		Name   string `json:"name"`
		Colour string `json:"colour"`
	}
	tokenPair, err := ts.GetTokenPair(e.Name, tokenstore.TokenTypeUser)
	if err != nil {
		return fmt.Errorf("get user token pair for env %s: %v", e.Name, err)
	}
	resource := fmt.Sprintf(tagResourcePattern, tokenPair.PeaxID)
	existingTagsPayload, err := Get(e, ts, resource)
	if err != nil {
		return fmt.Errorf("fetch existing tags: %v", err)
	}
	existingTags := make([]documenttagPayload, 0)
	err = json.Unmarshal([]byte(existingTagsPayload), &existingTags)
	if err != nil {
		return fmt.Errorf("unmarshal tag payload: %v", err)
	}
	missingTags := make([]string, 0)
	for _, needed := range tags {
		found := false
		for _, existing := range existingTags {
			if existing.Name == needed {
				found = true
				break
			}
		}
		if !found {
			missingTags = append(missingTags, needed)
		}
	}
	for _, tag := range missingTags {
		payload := documenttagPayload{Name: tag, Colour: utils.PickRandomHexColour()}
		jsonBytes, err := json.Marshal(payload)
		if err != nil {
			return fmt.Errorf("marshal %v: %v", payload, err)
		}
		file, err := ioutil.TempFile(os.TempDir(), "documenttag-")
		if err != nil {
			return fmt.Errorf("create temp file for documenttag payload: %v", err)
		}
		defer os.Remove(file.Name())
		defer file.Close()
		_, err = file.Write(jsonBytes)
		if err != nil {
			return fmt.Errorf("write to file %s: %v", file.Name(), err)
		}
		_, err = Post(e, ts, resource, file.Name())
		if err != nil {
			return fmt.Errorf("post documenttag %v: %v", payload, err)
		}
	}
	return nil
}

func addTags(documentID string, tags []string, e *env.Environment, ts *tokenstore.TokenStore) error {
	type tagPatchValue struct {
		Name string `json:"name"`
	}
	type patchOperation struct {
		Operation string          `json:"op"`
		Path      string          `json:"path"`
		Value     []tagPatchValue `json:"value"`
	}
	tagPatchValues := make([]tagPatchValue, 0)
	for _, tag := range tags {
		tagPatchValues = append(tagPatchValues, tagPatchValue{Name: tag})
	}
	payload := []patchOperation{patchOperation{Operation: "replace", Path: "/tags", Value: tagPatchValues}}
	jsonBytes, err := json.Marshal(payload)
	if err != nil {
		return fmt.Errorf("marshal %v: %v", payload, err)
	}
	file, err := ioutil.TempFile(os.TempDir(), "tagpatch-")
	if err != nil {
		return fmt.Errorf("create temp file for tagpatch payload: %v", err)
	}
	defer os.Remove(file.Name())
	defer file.Close()
	_, err = file.Write(jsonBytes)
	if err != nil {
		return fmt.Errorf("write to file %s: %v", file.Name(), err)
	}
	resource := fmt.Sprintf(documentResourcePattern, documentID)
	_, err = Patch(e, ts, resource, file.Name())
	if err != nil {
		return fmt.Errorf("patch documenttags %v: %v", payload, err)
	}
	return nil
}

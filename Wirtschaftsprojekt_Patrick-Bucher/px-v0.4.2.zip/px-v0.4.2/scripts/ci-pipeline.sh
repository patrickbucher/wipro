#!/usr/bin/bash

# insert additional scripts here
scripts="
    ci-px-help-test.sh
    ci-px-login-logout-test.sh
    ci-px-upload-test.sh
    ci-px-env-test.sh
    ci-px-agent-login-logout-test.sh
    ci-px-version-test.sh
    ci-px-deliver-test.sh
    ci-px-get-test.sh
    ci-px-post-test.sh
    ci-px-put-delete-test.sh
    ci-px-patch-test.sh
    ci-px-upload-recursively-test.sh
    ci-px-autotag-test.sh
"

# These test are not included in the pipeline, because they take too long by nature:
#
# - standalone-px-upload-retry-test.sh
#
# Execute them manually as needed.

cleanup () {
    rm -f px
    rm -f ~/.px-tokens
}

# build step
go build -ldflags="-X main.Version=$(git describe --tags)" ../cmd/px.go
if [ $? -ne 0 ]
then
    echo "failed at build stage"
    exit 1
fi

# read optional envvars file
if [ -f "envvars.sh" ]
then
    source ./envvars.sh
fi

# execute tests
for script in $scripts
do
    echo "executing script ${script}"
    source "${script}"
    exit_code=$?
    if [ $exit_code -ne 0 ]; then
        echo "script ${script} failed with exit code ${exit_code}"
        cleanup
        exit 1
    fi
done
n_tests="$(echo "${scripts}" | wc -w)"
echo "${n_tests} tests passed successfully"
cleanup

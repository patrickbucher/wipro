#!/usr/bin/bash

# wait for 5½ minutes for access token to expire
WAIT_SECONDS=330

source standalone.sh

if [ $? -ne 0 ]
then
    echo "failed at standalone test initialization"
    cleanup
    exit 1
fi

./px login -e test -u "$TEST_USERNAME" -p "$TEST_PASSWORD" || exit 1

./px get document/api/v3/account/455.5462.5012.69/collection | jq > /dev/null
if [ $? -ne 0 ]
then
    echo "initial get failed"
    cleanup
    exit 1
fi

sleep "${WAIT_SECONDS}" 

./px get document/api/v3/account/455.5462.5012.69/collection | jq > /dev/null
if [ $? -ne 0 ]
then
    echo "another get after ${WAIT_SECONDS} failed"
    cleanup
    exit 1
fi

cleanup

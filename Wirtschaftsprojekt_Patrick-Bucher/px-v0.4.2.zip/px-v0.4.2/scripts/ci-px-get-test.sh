#!/usr/bin/bash

# login
./px login -e test -u "$TEST_USERNAME" -p "$TEST_PASSWORD"
if [ $? -ne 0 ]
then
    echo "login to test failed"
    exit 1
fi

# get
./px get document/api/v3/account/455.5462.5012.69/collection | jq > /dev/null
if [ $? -ne 0 ]
then
    echo "get collection failed"
    exit 1
fi

# logout
./px logout -e test
if [ $? -ne 0 ]
then
    echo "logout from test failed"
    exit 1
fi

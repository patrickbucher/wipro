#!/usr/bin/bash

# wait for 5½ minutes for access token to expire
WAIT_SECONDS=330

source standalone.sh

if [ $? -ne 0 ]
then
    echo "failed at standalone test initialization"
    cleanup
    exit 1
fi

./px login -e test -u "$TEST_USERNAME" -p "$TEST_PASSWORD" || exit 1

./px upload -e test testdata/document.pdf
if [ $? -ne 0 ]
then
    echo "initial upload failed"
    cleanup
    exit 1
fi

sleep "${WAIT_SECONDS}" 

./px upload -e test testdata/document.pdf
if [ $? -ne 0 ]
then
    echo "another upload after ${WAIT_SECONDS} failed"
    cleanup
    exit 1
fi

cleanup

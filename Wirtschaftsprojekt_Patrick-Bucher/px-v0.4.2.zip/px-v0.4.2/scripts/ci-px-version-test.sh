#!/usr/bin/bash

output="$(./px version)"
echo $output | grep -E '^v[0-9]+\.[0-9]+\.[0-9]+(-[0-9]+-g[0-9a-fA-F]{7})?$' > /dev/null
[ $? -eq 0 ] || exit 1

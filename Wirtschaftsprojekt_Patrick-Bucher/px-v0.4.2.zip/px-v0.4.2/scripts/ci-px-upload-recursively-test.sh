#!/usr/bin/bash

./px login -e test -u "$TEST_USERNAME" -p "$TEST_PASSWORD"
if [ $? -ne 0 ]
then
    echo "login to test failed"
    exit 1
fi

total=$(find testdata/docfolder-small -type f | wc -l)
uploaded=$(./px upload -e test -v -r testdata/docfolder-small 2>upload.err | jq -r '.uploaded')
if [ $? -ne 0 ]
then
    echo "upload of documents to test failed"
    exit 1
fi
if [ "$total" != "$uploaded" ]
then
    echo "tried to upload ${total} documents, ${uploaded} succeeded"
    exit 1
fi

status_lines="$(grep -E -c '^[0-9]+/[0-9]+$' upload.err)"
if [ "$status_lines" != "$total" ]
then
    echo "expected ${total} status lines in upload.err, got ${status_lines}"
    exit 1
fi
rm -f upload.err

./px logout -e test
if [ $? -ne 0 ]
then
    echo "logout from test failed"
    exit 1
fi

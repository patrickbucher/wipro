#!/usr/bin/bash

# agent login
./px agent-login -e test -u "$TEST_DELIVERY_CLIENT_ID" -p "$TEST_DELIVERY_SECRET" -v 2> px-agent-login-logout-test.stderr
if [ $? -ne 0 ]
then
    echo "agent login to test failed"
    exit 1
fi
success_message=$(cat px-agent-login-logout-test.stderr)
rm -f px-agent-login-logout-test.stderr
if [ -z "${success_message}" ]
then
    echo "success message for 'px agent-login' missing after invoking with -v parameter"
    exit 1
fi

# check access token (present)
access_token=$(jq -r <${HOME}/.px-tokens '.tokens.agent_test.access_token')
if [ -z $access_token ]
then
    echo "no agent access token retrieved"
    exit 1
fi

# logout
./px agent-logout -e test -v 2> px-agent-login-logout-test.stderr
if [ $? -ne 0 ]
then
    echo "agent logout from test failed"
    exit 1
fi
success_message=$(cat px-agent-login-logout-test.stderr)
rm -f px-agent-login-logout-test.stderr
if [ -z "${success_message}" ]
then
    echo "success message for 'px agent-logout' missing after invoking with -v parameter"
    exit 1
fi

# check access token (missing)
access_token=$(jq -r <${HOME}/.px-tokens '.tokens.agent_test.access_token')
if [ $access_token != "null" ]
then
    echo "agent access token was not removed"
    exit 1
fi

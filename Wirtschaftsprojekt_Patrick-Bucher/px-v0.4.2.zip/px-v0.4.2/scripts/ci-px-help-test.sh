#!/usr/bin/bash

commands="
    help
    login
    logout
    agent-login
    agent-logout
    env
    upload
    get
    version
    deliver
    post
    put
    patch
    delete
"

# general case: get help on a specific command
for cmd in $commands
do
    output="$(./px help $cmd)"
    [ $? -eq 0 ] || exit 1
    if [ -z "$output" ]
    then
        echo "help for command ${cmd} missing"
        exit 1
    fi
done


# special case: general information
output="$(./px help)"
[ $? -eq 0 ] || exit 1
if [ -z "$output" ]
then
    echo "general help for missing"
    exit 1
fi

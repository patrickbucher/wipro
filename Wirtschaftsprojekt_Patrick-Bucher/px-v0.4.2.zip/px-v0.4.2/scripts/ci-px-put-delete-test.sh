#!/usr/bin/bash

# login
./px login -e test -u "$TEST_USERNAME" -p "$TEST_PASSWORD"
if [ $? -ne 0 ]
then
    echo "login to test failed"
    exit 1
fi

# put pictures in different formats
pictures="
    testdata/profile-picture.png
    testdata/profile-picture.jpg
    testdata/profile-picture.gif
"

for picture in $pictures
do
    ./px put -p "$picture" profile/api/v3/profile/455.5462.5012.69/picture/avatar
    if [ $? -ne 0 ]
    then
        echo "put profile picture ${picture} failed"
        exit 1
    fi
done

# delete the picture
./px delete profile/api/v3/profile/455.5462.5012.69/picture/avatar
if [ $? -ne 0 ]
then
    echo "delete profile picture failed"
    exit 1
fi

# logout
./px logout -e test
if [ $? -ne 0 ]
then
    echo "logout from test failed"
    exit 1
fi

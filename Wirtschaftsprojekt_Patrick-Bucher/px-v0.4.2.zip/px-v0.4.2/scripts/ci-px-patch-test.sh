#!/usr/bin/bash

# login
./px login -e test -u "$TEST_USERNAME" -p "$TEST_PASSWORD"
if [ $? -ne 0 ]
then
    echo "login to test failed"
    exit 1
fi

# upload a document and store its UUID
uuid=$(./px upload -e test testdata/document.pdf | jq -r '.documentId')
if [ -z $uuid ]
then
    echo "upload failed"
    exit 1
fi

# patch the document
uuidPatched=$(./px patch -p testdata/document-patch.json "document/api/v3/document/${uuid}" | jq -r '.documentId')
if [ "$uuid" != "$uuidPatched" ]
then
    echo "patching document ${uuid} failed"
    exit 1
fi

# logout
./px logout -e test
if [ $? -ne 0 ]
then
    echo "logout from test failed"
    exit 1
fi

#!/usr/bin/bash

rm -rf ~/.px-tokens

# login
./px login -e test -u "$TEST_USERNAME" -p "$TEST_PASSWORD" -v 2> px-login-logout-test.stderr
if [ $? -ne 0 ]
then
    echo "login to test failed"
    exit 1
fi
success_message=$(cat px-login-logout-test.stderr)
rm -f px-login-logout-test.stderr
if [ -z "${success_message}" ]
then
    echo "success message for 'px login' missing after invoking with -v parameter"
    exit 1
fi

# check access token (present)
access_token="$(jq -r <${HOME}/.px-tokens '.tokens.user_test.access_token')"
if [ -z $access_token ]
then
    echo "no access token retrieved"
    exit 1
fi

# check if environment and token type is set
environment="$(jq -r <${HOME}/.px-tokens '.tokens.user_test.environment')"
token_type="$(jq -r <${HOME}/.px-tokens '.tokens.user_test.token_type')"
if [ "$environment" != 'test' ]
then
    echo "environment is not 'test', but ${environment}"
    exit 1
fi
if [ "$token_type" != 'user' ]
then
    echo "token_type is not 'user', but ${token_type}"
    exit 1
fi

# logout
./px logout -e test
if [ $? -ne 0 ]
then
    echo "logout from test failed"
    exit 1
fi

# check access token (missing)
access_token=$(jq -r <${HOME}/.px-tokens '.tokens.user_test.access_token')
if [ $access_token != "null" ]
then
    echo "access token was not removed"
    exit 1
fi

# logout from all environments
./px logout -a -v 2> px-login-logout-test.stderr
if [ $? -ne 0 ]
then
    echo "logout from test failed"
    exit 1
fi
success_message=$(cat px-login-logout-test.stderr)
rm -f px-login-logout-test.stderr
if [ -z "${success_message}" ]
then
    echo "success message for 'px logout' missing after invoking with -v parameter"
    exit 1
fi

# check no more tokens
n_tokens=$(jq <${HOME}/.px-tokens '.tokens | length')
if [ $n_tokens != "0" ]
then
    echo "${n_tokens} tokens have not been removed"
    exit 1
fi

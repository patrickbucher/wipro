#!/usr/bin/bash

# login
./px login -e test -u "$TEST_USERNAME" -p "$TEST_PASSWORD"
if [ $? -ne 0 ]
then
    echo "login to test failed"
    exit 1
fi

# post
./px post -p testdata/organization.json /network/api/v3/network/455.5462.5012.69/userorganizationrelationship \
    | jq > /dev/null
if [ $? -ne 0 ]
then
    echo "post organization failed"
    exit 1
fi

# logout
./px logout -e test
if [ $? -ne 0 ]
then
    echo "logout from test failed"
    exit 1
fi

#!/usr/bin/bash

./px login -e test -u "$TEST_USERNAME" -p "$TEST_PASSWORD"
if [ $? -ne 0 ]
then
    echo "login to test failed"
    exit 1
fi

total=$(find testdata/docfolder-small -type f | wc -l)
./px upload -e test -t -r testdata/docfolder-small | jq > report.json
if [ $? -ne 0 ]
then
    echo "upload of documents to test with autotagging failed"
    exit 1
fi
uploaded=$(jq -r '.uploaded' <report.json)
if [ "$total" != "$uploaded" ]
then
    echo "tried to upload ${total} documents with autotagging, ${uploaded} succeeded"
    exit 1
fi

# docfolder contains four documents
for i in {0..3}
do
    n_tags="$(jq -r ".documents[$i].tags | length" <report.json)"
    if [ "$n_tags" == '0' ]
    then
        echo "no tags created for document upload ${i}"
        exit 1
    fi
done
rm -f report.json

./px logout -e test
if [ $? -ne 0 ]
then
    echo "logout from test failed"
    exit 1
fi

#!/usr/bin/bash

# login
./px login -e test -u "$TEST_USERNAME" -p "$TEST_PASSWORD"
if [ $? -ne 0 ]
then
    echo "login to test failed"
    exit 1
fi

# check if default environment is test
default_environment="$(jq -r '.default_environment' < ~/.px-tokens)"
if [ "$default_environment" != "test" ]
then
    echo "expected 'test' as default environment, got ${default_environment}"
    exit 1
fi

# check if `px env` comes to the same conclusion
px_env_output="$(./px env)"
if [ "$px_env_output" != "test" ]
then
    echo "expected 'test' as output from px env, got ${px_env_output}"
    exit 1
fi

# login to other environment
./px login -e dev -u "$DEV_USERNAME" -p "$DEV_PASSWORD"
if [ $? -ne 0 ]
then
    echo "login to dev failed"
    exit 1
fi

# check if `px env` uses the new environment
px_env_output="$(./px env)"
if [ "$px_env_output" != 'dev' ]
then
    echo "expected 'dev' as output from px env, got ${px_env_output}"
    exit 1
fi

# switch back to test (using verbose flag)
./px env -v 'test' 2> px-env-test.stderr
if [ $? -ne 0 ]
then
    echo "unable to switch to environment test"
    exit 1
fi
success_message=$(cat px-env-test.stderr)
rm -f px-env-test.stderr
if [ -z "${success_message}" ]
then
    echo "success message for 'px env' missing after invoking with -v parameter"
    exit 1
fi

# check if `px env` uses the old environment again
px_env_output="$(./px env)"
if [ "$px_env_output" != 'test' ]
then
    echo "expected 'test' as output from px env, got ${px_env_output}"
    exit 1
fi

# logout from dev (should not affect default_environment)
./px logout -e dev
default_environment="$(jq -r '.default_environment' < ~/.px-tokens)"
if [ "$default_environment" != 'test' ]
then
    echo "expected 'test' to stay default environment after logout, got ${default_environment}"
    exit 1
fi

# logout from all environments (default_environment should be null afterwards)
./px logout -a
default_environment="$(jq -r '.default_environment' < ~/.px-tokens)"
if [ "$default_environment" != 'null' ]
then
    echo "expected default_environment to be empty after logout from all environments"
    exit 1
fi

# try to switch to environment without tokens: must fail
./px env 'stage' 2> /dev/null
if [ $? -eq 0 ]
then
    echo "switching to 'stage' must not be possible due to missing tokens"
    exit 1
fi

# try to switch to some bogus environment: must fail
./px env 'arbalo' 2> /dev/null
if [ $? -eq 0 ]
then
    echo "switching to 'arbalo' is an absurd operation and therefore must fail"
    exit 1
fi

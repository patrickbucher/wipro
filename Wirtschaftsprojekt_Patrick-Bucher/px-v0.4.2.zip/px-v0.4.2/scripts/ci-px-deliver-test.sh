#!/usr/bin/bash

./px agent-login -e test -u "$TEST_DELIVERY_CLIENT_ID" -p "$TEST_DELIVERY_SECRET"
if [ $? -ne 0 ]
then
    echo "agent login to test failed"
    exit 1
fi
 
id=$(./px deliver -e test -meta testdata/deliver-metadata.json testdata/document.pdf | jq -r .id)
if [ $? -ne 0 ]
then
    echo "delivery of document to test failed"
    exit 1
fi
echo $id | grep -E '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$' > /dev/null
[ $? -eq 0 ] || exit 1

#!/usr/bin/bash

# wait for 5½ minutes for access token to expire
WAIT_SECONDS=330

source standalone.sh

if [ $? -ne 0 ]
then
    echo "failed at standalone test initialization"
    cleanup
    exit 1
fi

./px agent-login -e test -u "$TEST_DELIVERY_CLIENT_ID" -p "$TEST_DELIVERY_SECRET" -v || exit 1

./px deliver -e test -m testdata/deliver-metadata.json testdata/document.pdf
if [ $? -ne 0 ]
then
    echo "initial delivery failed"
    cleanup
    exit 1
fi

sleep "${WAIT_SECONDS}" 

./px deliver -e test -m testdata/deliver-metadata.json testdata/document.pdf
if [ $? -ne 0 ]
then
    echo "another delivery after ${WAIT_SECONDS} failed"
    cleanup
    exit 1
fi

cleanup

#!/usr/bin/bash

./px login -e test -u "$TEST_USERNAME" -p "$TEST_PASSWORD"
if [ $? -ne 0 ]
then
    echo "login to test failed"
    exit 1
fi

./px upload -e test testdata/document.pdf > /dev/null
if [ $? -ne 0 ]
then
    echo "upload of document to test failed"
    exit 1
fi

./px logout -e test
if [ $? -ne 0 ]
then
    echo "logout from test failed"
    exit 1
fi

#!/usr/bin/bash

# build step
go build -ldflags="-X main.Version=$(git describe --tags)" ../cmd/px.go
if [ $? -ne 0 ]
then
    echo "failed at build stage"
    exit 1
fi

# read optional envvars file
if [ -f "envvars.sh" ]
then
    source ./envvars.sh
fi

cleanup () {
    rm -f px
}

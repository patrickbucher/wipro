package main

import (
	"errors"
	"flag"
	"fmt"
	"os"
	"px/env"
	"px/help"
	"px/requests"
	"px/tokenstore"
	"px/utils"
	"strings"
)

// Version indicates the current version of px, which is derived from the
// current SCM tag, and set using a linker flag.
var Version string

const (
	envUsage       = "the PEAX environment to be used (dev, test, stage, prod, etc.)"
	userUsage      = "the PEAX username (email)"
	passUsage      = "the password for the PEAX account"
	secureUsage    = "store the tokens in the secure key store"
	insecureUsage  = "do not store the tokens in the secure key store"
	allEnvsUsage   = "whether or not logout should be performed on all environments"
	verboseUsage   = "print success message to STDERR"
	metaUsage      = "provide JSON meta data for the document"
	payloadUsage   = "provide a file as the payload for the request"
	recursiveUsage = "upload a folder containing documents recursively"
	tagUsage       = "automatically tag documents from containing folder names"
)

type command struct {
	run  func(tokenStore *tokenstore.TokenStore) error
	info string
	help func() string
}

var commands = map[string]command{
	"login":        {login, help.LoginInfo, help.Login},
	"logout":       {logout, help.LogoutInfo, help.Logout},
	"agent-login":  {agentLogin, help.AgentLoginInfo, help.AgentLogin},
	"agent-logout": {agentLogout, help.AgentLogoutInfo, help.AgentLogout},
	"upload":       {upload, help.UploadInfo, help.Upload},
	"env":          {nil, help.EnvInfo, help.Env},
	"help":         {nil, help.HelpInfo, help.Help},
	"version":      {version, help.VersionInfo, help.Version},
	"deliver":      {deliver, help.DeliverInfo, help.Deliver},
	"get":          {get, help.GetInfo, help.Get},
	"post":         {post, help.PostInfo, help.Post},
	"put":          {put, help.PutInfo, help.Put},
	"patch":        {patch, help.PatchInfo, help.Patch},
	"delete":       {dlete, help.DeleteInfo, help.Delete},
}

func main() {
	if len(os.Args) < 2 {
		fatalMsg(fmt.Sprintf("No subcommand was provided. Usage: %s [subcommand]\n", os.Args[0]))
	}
	commandName := os.Args[1]
	command, ok := commands[commandName]
	if !ok {
		fmt.Fprintf(os.Stderr, "unknown subcommand '%s'", commandName)
		return
	}

	tokenStore := buildup()
	defer cleanup(tokenStore)

	if command.run != nil {
		if err := command.run(tokenStore); err != nil {
			fatalErr(commandName, err)
		}
		return
	}
	switch commandName {
	case "help":
		helpForCommand := ""
		if len(os.Args) > 2 {
			helpForCommand = os.Args[2]
		}
		showHelp(helpForCommand)
	case "env":
		defaultEnv, err := environment(tokenStore)
		if err != nil {
			fatalErr("env", err)
		}
		tokenStore.DefaultEnvironment = defaultEnv.Name
	}
}

func showHelp(commandName string) {
	if commandName == "" {
		commandInfoMap := make(map[string]string, 0)
		for name, entry := range commands {
			commandInfoMap[name] = entry.info
		}
		fmt.Println(help.Unspecified(commandInfoMap))
		return
	}
	command, ok := commands[commandName]
	if !ok {
		fatalMsg(fmt.Sprintf("no such command '%s' to show help for", commandName))
	}
	fmt.Println(command.help())
}

func login(tokenStore *tokenstore.TokenStore) error {
	args, err := parseLoginCommand(promptCredentialsIfMissing)
	if err != nil {
		return fmt.Errorf("parsing command line options: %v", err)
	}
	credentials := requests.Credentials{
		Username:  args.username,
		Password:  args.password,
		GrantType: "password",
		ClientID:  "peax.portal",
	}
	tokenPair, err := requests.RequestTokenPair(args.environment, credentials, promptSecondFactor)
	if err != nil {
		return fmt.Errorf("request token pairs: %v", err)
	}
	if args.verbose {
		fmt.Fprintf(os.Stderr, "login for user %s to environment %s was successful\n",
			args.username, args.environment.Name)
	}
	tokenPair.UseKeystore = args.secretStore
	if err := tokenStore.SaveTokenPair(tokenPair); err == nil {
		tokenStore.DefaultEnvironment = args.environment.Name
	}
	return err
}

func agentLogin(tokenStore *tokenstore.TokenStore) error {
	args, err := parseLoginCommand(promptAgentCredentialsIfMissing)
	if err != nil {
		return fmt.Errorf("parsing command line options: %v", err)
	}
	credentials := requests.ClientCredentials{
		ClientID:     args.username,
		ClientSecret: args.password,
		GrantType:    "client_credentials",
	}
	tokenPair, err := requests.RequestAgentTokenPair(args.environment, credentials)
	if err != nil {
		return fmt.Errorf("request token pairs for agent: %v", err)
	}
	if args.verbose {
		fmt.Fprintf(os.Stderr, "agent login for client %s to environment %s was successful\n",
			args.username, args.environment.Name)
	}
	tokenPair.UseKeystore = args.secretStore
	return tokenStore.SaveTokenPair(tokenPair)
}

type loginArguments struct {
	environment *env.Environment
	username    string
	password    string
	secretStore bool
	verbose     bool
}

func parseLoginCommand(supplementInput func(*string, *string) error) (*loginArguments, error) {
	var environment, username, password string
	var secure, insecure, verbose bool

	loginCommand := flag.NewFlagSet("login", flag.ExitOnError)
	loginCommand.StringVar(&environment, "env", "dev", envUsage)
	loginCommand.StringVar(&environment, "e", "dev", envUsage+" (shorthand)")
	loginCommand.StringVar(&username, "user", "", userUsage)
	loginCommand.StringVar(&username, "u", "", userUsage+" (shorthand)")
	loginCommand.StringVar(&password, "pass", "", passUsage)
	loginCommand.StringVar(&password, "p", "", passUsage+" (shorthand)")
	loginCommand.BoolVar(&secure, "secure", false, secureUsage)
	loginCommand.BoolVar(&secure, "s", false, secureUsage+" (shortand)")
	loginCommand.BoolVar(&insecure, "insecure", false, insecureUsage)
	loginCommand.BoolVar(&insecure, "i", false, insecureUsage+" (shortand)")
	loginCommand.BoolVar(&verbose, "verbose", false, verboseUsage)
	loginCommand.BoolVar(&verbose, "v", false, verboseUsage+" (shorthand)")
	loginCommand.Parse(os.Args[2:])

	if secure && insecure {
		return nil, fmt.Errorf("flags secure and insecure are mutual exclusive, but both provided")
	}
	peaxEnv, err := env.GetEnvironment(environment)
	if err != nil {
		return nil, fmt.Errorf("get environment %s: %v", environment, err)
	}
	err = supplementInput(&username, &password)
	if err != nil {
		return nil, fmt.Errorf("prompt login parameters: %v", err)
	}
	secretStore := peaxEnv.Confidential && !insecure || !peaxEnv.Confidential && secure

	args := loginArguments{peaxEnv, username, password, secretStore, verbose}
	return &args, nil
}

func promptCredentialsIfMissing(username, password *string) error {
	if *username == "" {
		input, err := utils.ConsoleInput("Username: ", utils.InputString)
		if err != nil {
			return err
		}
		*username = input
	}
	if *password == "" {
		input, err := utils.ConsoleInput("Password: ", utils.InputPassword)
		if err != nil {
			return err
		}
		*password = input
	}
	return nil
}

func promptAgentCredentialsIfMissing(clientID, clientSecret *string) error {
	if *clientID == "" {
		input, err := utils.ConsoleInput("Client ID: ", utils.InputString)
		if err != nil {
			return err
		}
		*clientID = input
	}
	if *clientSecret == "" {
		input, err := utils.ConsoleInput("Client Secret: ", utils.InputString)
		if err != nil {
			return err
		}
		*clientSecret = input
	}
	return nil
}

func promptSecondFactor(secondFactor string) (string, error) {
	secondFactorPrompt := fmt.Sprintf("%s Code: ", strings.ToUpper(secondFactor))
	secondFactorInput, err := utils.ConsoleInput(secondFactorPrompt, utils.InputString)
	if err != nil {
		return "", fmt.Errorf("prompting 2nd factor %s: %v", secondFactor, err)
	}
	secondFactorInput = strings.TrimSpace(secondFactorInput)
	return secondFactorInput, nil
}

func logout(tokenStore *tokenstore.TokenStore) error {
	return doLogout(tokenStore, tokenstore.TokenTypeUser)
}

func agentLogout(tokenStore *tokenstore.TokenStore) error {
	return doLogout(tokenStore, tokenstore.TokenTypeAgent)
}

func doLogout(tokenStore *tokenstore.TokenStore, tokenType tokenstore.TokenType) error {
	var environment string
	var allEnvs, verbose bool
	logoutCommand := flag.NewFlagSet("logout", flag.ExitOnError)
	logoutCommand.BoolVar(&allEnvs, "all", false, allEnvsUsage)
	logoutCommand.BoolVar(&allEnvs, "a", false, allEnvsUsage+" (shorthand)")
	logoutCommand.StringVar(&environment, "env", "", envUsage)
	logoutCommand.StringVar(&environment, "e", "", envUsage+" (shorthand)")
	logoutCommand.BoolVar(&verbose, "verbose", false, verboseUsage)
	logoutCommand.BoolVar(&verbose, "v", false, verboseUsage+" (shorthand)")
	logoutCommand.Parse(os.Args[2:])

	if environment != "" && allEnvs {
		return fmt.Errorf("conflict: log out from one specific or from all environments?")
	} else if allEnvs {
		tokenStore.RemoveAllTokenPairs(tokenType)
	} else if environment != "" {
		if _, err := env.GetEnvironment(environment); err != nil {
			return fmt.Errorf("logout from environment %s: %v", environment, err)
		}
		tokenStore.RemoveTokenPair(environment, tokenType)
	} else {
		return fmt.Errorf("no environment specified to logout from")
	}
	if tokenStore.DefaultEnvironment == environment || allEnvs {
		tokenStore.DefaultEnvironment = ""
	}
	if verbose {
		if allEnvs {
			fmt.Fprintf(os.Stderr, "%s logout from all environments was successful\n", tokenType)
		} else {
			fmt.Fprintf(os.Stderr, "%s logout from environment %s was successful\n", tokenType, environment)
		}
	}
	return nil
}

func upload(tokenStore *tokenstore.TokenStore) error {
	var environment string
	var recursive, verbose, tag bool
	uploadCommand := flag.NewFlagSet("upload", flag.ExitOnError)
	uploadCommand.StringVar(&environment, "env", "", envUsage)
	uploadCommand.StringVar(&environment, "e", "", envUsage+" (shorthand)")
	uploadCommand.BoolVar(&recursive, "recursive", false, recursiveUsage)
	uploadCommand.BoolVar(&recursive, "r", false, recursiveUsage+" (shorthand)")
	uploadCommand.BoolVar(&verbose, "verbose", false, verboseUsage)
	uploadCommand.BoolVar(&verbose, "v", false, verboseUsage+" (shorthand)")
	uploadCommand.BoolVar(&tag, "tag", false, tagUsage)
	uploadCommand.BoolVar(&tag, "t", false, tagUsage+" (shorthand)")
	uploadCommand.Parse(os.Args[2:])

	args := uploadCommand.Args()
	if len(args) != 1 {
		return fmt.Errorf("one parameter (document or folder) is allowed, %d given", len(args))
	}
	fileArg := args[0]
	if utils.FileMissing(fileArg) {
		return fmt.Errorf("the document or folder %s does not exist", fileArg)
	}

	peaxEnv, err := getEnv(environment, tokenStore)
	if err != nil {
		return fmt.Errorf("get environment from param '%s': %v", environment, err)
	}

	var reply string
	if recursive {
		reply, err = requests.UploadRecursively(peaxEnv, tokenStore, fileArg, verbose, tag)
	} else {
		if tag {
			return fmt.Errorf("automatic tagging is only available for recursive uploads")
		}
		reply, err = requests.UploadDocument(peaxEnv, tokenStore, fileArg)
	}
	if err != nil {
		return fmt.Errorf("upload document %s: %v", fileArg, err)
	}
	if verbose && !recursive {
		fmt.Fprintf(os.Stderr, "document %s has been uploaded successfully\n", fileArg)
	}
	fmt.Println(reply)
	return nil
}

func environment(tokenStore *tokenstore.TokenStore) (*env.Environment, error) {
	var verbose bool
	envCommand := flag.NewFlagSet("env", flag.ExitOnError)
	envCommand.BoolVar(&verbose, "verbose", false, verboseUsage)
	envCommand.BoolVar(&verbose, "v", false, verboseUsage+" (shorthand)")
	envCommand.Parse(os.Args[2:])

	args := envCommand.Args()
	if len(args) == 1 {
		// set environment
		envParam := args[0]
		setEnvironment, err := env.GetEnvironment(envParam)
		if err != nil {
			return nil, fmt.Errorf("cannot set environment '%s': %v", envParam, err)
		}
		var hasUnsafeToken, hasSafeToken = false, false
		unsafeToken, err := tokenStore.GetTokenPair(envParam, tokenstore.TokenTypeUser)
		hasUnsafeToken = (unsafeToken != nil && err == nil)
		if !hasUnsafeToken {
			hasSafeToken = tokenstore.HasSecretTokens(envParam, tokenstore.TokenTypeUser)
		}
		if !hasUnsafeToken && !hasSafeToken {
			return nil, fmt.Errorf("no tokens for environment '%s', you must login first", envParam)
		}
		if verbose {
			fmt.Fprintf(os.Stderr, "switched to environment %s successfully\n", envParam)
		}
		return setEnvironment, nil
	} else if len(args) == 0 {
		// get environment
		defaultEnv := tokenStore.DefaultEnvironment
		if defaultEnv == "" {
			return nil, fmt.Errorf("no default environment is set, you must login first")
		}
		getEnvironment, err := env.GetEnvironment(defaultEnv)
		if err != nil {
			return nil, fmt.Errorf("invalid environment '%s': %v", defaultEnv, err)
		}
		fmt.Println(getEnvironment.Name)
		return getEnvironment, nil
	}
	return nil, fmt.Errorf("use one parameter to set the environment, or no parameters to retrieve it")
}

func version(_ *tokenstore.TokenStore) error {
	fmt.Println(Version)
	return nil
}

func deliver(tokenStore *tokenstore.TokenStore) error {
	var environment, metaFile string
	deliverCommand := flag.NewFlagSet("deliver", flag.ExitOnError)
	deliverCommand.StringVar(&environment, "env", "", envUsage)
	deliverCommand.StringVar(&environment, "e", "", envUsage+" (shorthand)")
	deliverCommand.StringVar(&metaFile, "meta", "", metaUsage)
	deliverCommand.StringVar(&metaFile, "m", "", metaUsage+" (shorthand)")
	deliverCommand.Parse(os.Args[2:])

	if strings.TrimSpace(environment) == "" {
		return errors.New("-e/-env parameter is required for delivery endpoint")
	}

	documents := deliverCommand.Args()
	if len(documents) != 1 {
		return fmt.Errorf("exactly one parameter (document file name) is allowed, %d given", len(documents))
	}

	peaxEnv, err := getEnv(environment, tokenStore)
	if err != nil {
		return fmt.Errorf("get environment from param '%s': %v", environment, err)
	}

	payload, err := requests.Deliver(peaxEnv, tokenStore, documents[0], metaFile)
	if err != nil {
		return fmt.Errorf("deliver document %s to %s: %v", documents[0], peaxEnv.Name, err)
	}
	fmt.Println(payload)
	return nil
}

func get(tokenStore *tokenstore.TokenStore) error {
	var environment string
	getCommand := flag.NewFlagSet("get", flag.ExitOnError)
	getCommand.StringVar(&environment, "env", "", envUsage)
	getCommand.StringVar(&environment, "e", "", envUsage+" (shorthand)")
	getCommand.Parse(os.Args[2:])

	resource := getCommand.Args()
	if len(resource) != 1 {
		return fmt.Errorf("exactly one parameter (resource path) is allowed, %d given", len(resource))
	}

	peaxEnv, err := getEnv(environment, tokenStore)
	if err != nil {
		return fmt.Errorf("get environment from param '%s': %v", environment, err)
	}

	payload, err := requests.Get(peaxEnv, tokenStore, resource[0])
	if err != nil {
		return fmt.Errorf("get %s from %s: %v", resource[0], peaxEnv.Name, err)
	}
	fmt.Println(payload)
	return nil
}

func post(tokenStore *tokenstore.TokenStore) error {
	peaxEnv, payload, endpoint, err := parseHTTPCommand("post", tokenStore)
	if err != nil {
		return fmt.Errorf("parse POST command: %v", err)
	}
	responsePayload, err := requests.Post(peaxEnv, tokenStore, endpoint, payload)
	if err != nil {
		return fmt.Errorf("post payload %s to endpoint %s (environment %s): %v",
			payload, endpoint, peaxEnv.Name, err)
	}
	fmt.Println(responsePayload)
	return nil
}

func put(tokenStore *tokenstore.TokenStore) error {
	peaxEnv, payload, endpoint, err := parseHTTPCommand("put", tokenStore)
	if err != nil {
		return fmt.Errorf("parse PUT command: %v", err)
	}
	if err = requests.Put(peaxEnv, tokenStore, endpoint, payload); err != nil {
		return fmt.Errorf("put payload %s to endpoint %s (environment %s): %v",
			payload, endpoint, peaxEnv.Name, err)
	}
	return nil
}

func dlete(tokenStore *tokenstore.TokenStore) error {
	var environment string
	deleteCommand := flag.NewFlagSet("delete", flag.ExitOnError)
	deleteCommand.StringVar(&environment, "env", "", envUsage)
	deleteCommand.StringVar(&environment, "e", "", envUsage+" (shorthand)")
	deleteCommand.Parse(os.Args[2:])

	endpoints := deleteCommand.Args()
	if len(endpoints) != 1 {
		return fmt.Errorf("exactly one parameter (URL) is allowed, %d given", len(endpoints))
	}

	peaxEnv, err := getEnv(environment, tokenStore)
	if err != nil {
		return fmt.Errorf("get environment fro param '%s': %v", environment, err)
	}

	if err = requests.Delete(peaxEnv, tokenStore, endpoints[0]); err != nil {
		return fmt.Errorf("delete resource at endpoint %s (environment %s): %v",
			endpoints[0], peaxEnv.Name, err)
	}

	return nil
}

func patch(tokenStore *tokenstore.TokenStore) error {
	peaxEnv, payload, endpoint, err := parseHTTPCommand("patch", tokenStore)
	if err != nil {
		return fmt.Errorf("parse PATCH command: %v", err)
	}
	responsePayload, err := requests.Patch(peaxEnv, tokenStore, endpoint, payload)
	if err != nil {
		return fmt.Errorf("patch payload %s to endpoints %s (environment %s): %v",
			payload, endpoint, peaxEnv.Name, err)
	}
	fmt.Println(responsePayload)
	return nil
}

func parseHTTPCommand(method string, tokenStore *tokenstore.TokenStore) (*env.Environment, string, string, error) {
	var environment, payload string
	methodCommand := flag.NewFlagSet(method, flag.ExitOnError)
	methodCommand.StringVar(&environment, "env", "", envUsage)
	methodCommand.StringVar(&environment, "e", "", envUsage+" (shorthand)")
	methodCommand.StringVar(&payload, "payload", "", payloadUsage)
	methodCommand.StringVar(&payload, "p", "", payloadUsage+" (shorthand)")
	methodCommand.Parse(os.Args[2:])

	endpoints := methodCommand.Args()
	if len(endpoints) != 1 {
		return nil, "", "", fmt.Errorf("exactly one parameter (URL) is allowed, %d given", len(endpoints))
	}

	peaxEnv, err := getEnv(environment, tokenStore)
	if err != nil {
		return nil, "", "", fmt.Errorf("get environment from param '%s': %v", environment, err)
	}

	return peaxEnv, payload, endpoints[0], nil
}

func buildup() *tokenstore.TokenStore {
	var tokenStore *tokenstore.TokenStore
	if err := tokenstore.InitTokenStore(); err != nil {
		fmt.Fprintf(os.Stderr, "init token store: %v\n", err)
	}
	tokenStore, err := tokenstore.ReadFromJSONFile(tokenstore.DefaultTokenStoreFileName)
	if err != nil {
		fmt.Fprintf(os.Stderr, "read token store: %v\n", err)
		tokenStore = tokenstore.EmptyTokenStore()
	}
	return tokenStore
}

func cleanup(tokenStore *tokenstore.TokenStore) {
	if err := tokenStore.WriteToJSONFile(tokenstore.DefaultTokenStoreFileName); err != nil {
		fmt.Fprintf(os.Stderr, "write token store: %v\n", err)
	}
}

func getEnv(envParam string, tokenStore *tokenstore.TokenStore) (*env.Environment, error) {
	if envParam == "" {
		envParam = tokenStore.DefaultEnvironment
	}
	peaxEnv, err := env.GetEnvironment(envParam)
	if err != nil {
		return nil, fmt.Errorf("get environment %s: %v", envParam, err)
	}
	return peaxEnv, nil
}

func fatalMsg(msg string) {
	fmt.Fprintf(os.Stderr, "%s", msg)
	os.Exit(1)
}

func fatalErr(op string, err error) {
	fmt.Fprintf(os.Stderr, "%s: %v\n", op, err)
	os.Exit(1)
}

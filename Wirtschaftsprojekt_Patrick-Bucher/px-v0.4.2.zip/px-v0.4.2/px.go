// Package px contains data structures and functions for the PEAX Command Line
// Client, which is used by the `px` tool (see cmd/px.go).
package px

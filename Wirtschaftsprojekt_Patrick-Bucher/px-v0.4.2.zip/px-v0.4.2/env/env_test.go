package env

import "testing"

var getEnvironmentTests = []struct {
	inputName            string
	expectErr            bool
	expectedProxy        string
	expectedIDP          string
	expectedRealm        string
	expectedConfidential bool
}{
	{"dev",
		false,
		"sv-oauth-proxy-dev.osapps.peax.ch",
		"sv-idp-keycloak-dev.osapps.peax.ch",
		"peax-id-dev",
		false},
	{"devpatch",
		false,
		"sv-oauth-proxy-devpatch.osapps.peax.ch",
		"sv-idp-keycloak-devpatch.osapps.peax.ch",
		"peax-id-devpatch",
		false},
	{"test",
		false,
		"sv-oauth-proxy-test.osapps.peax.ch",
		"sv-idp-keycloak-test.osapps.peax.ch",
		"peax-id-test",
		false},
	{"testpatch",
		false,
		"sv-oauth-proxy-testpatch.osapps.peax.ch",
		"sv-idp-keycloak-testpatch.osapps.peax.ch",
		"peax-id-testpatch",
		false},
	{"stage",
		false,
		"sv-oauth-proxy-stage.osapps.peax.ch",
		"sv-idp-keycloak-stage.osapps.peax.ch",
		"peax-id-stage",
		false},
	{"prod",
		false,
		"sv-oauth-proxy-prod.osapps.peax.ch",
		"idp.peax.ch",
		"peax-id-prod",
		true},
	{"perf",
		false,
		"sv-oauth-proxy-perf.osapps.peax.ch",
		"sv-idp-keycloak-perf.osapps.peax.ch",
		"peax-id-perf",
		false},
	{"prototype",
		false,
		"sv-oauth-proxy-prototype.osapps.peax.ch",
		"sv-idp-keycloak-prototype.osapps.peax.ch",
		"peax-id-prototype",
		false},
	{"",
		true,
		"",
		"",
		"",
		false},
	{"foo",
		true,
		"",
		"",
		"",
		false},
}

func TestGetEnvironment(t *testing.T) {
	for _, env := range getEnvironmentTests {
		got, err := GetEnvironment(env.inputName)
		if err != nil && !env.expectErr {
			t.Errorf("GetEnvironment(%s) returned unexpected error: %v", env.inputName, err)
			continue
		}
		if err == nil && env.expectErr {
			t.Errorf("GetEnvironment(%s) did not return an error as expected", env.inputName)
			continue
		}
		if env.expectErr && got == nil {
			continue
		}
		if got.Proxy != env.expectedProxy {
			t.Errorf("Proxy for environment '%s' should be '%s', was '%s'", env.inputName, env.expectedProxy, got.Proxy)
		}
		if got.IDP != env.expectedIDP {
			t.Errorf("IDP for environment '%s' should be '%s', was '%s'", env.inputName, env.expectedIDP, got.IDP)
		}
		if got.Realm != env.expectedRealm {
			t.Errorf("Realm for environment '%s' should be '%s', was '%s'", env.inputName, env.expectedRealm, got.Realm)
		}
		if got.Confidential != env.expectedConfidential {
			t.Errorf("Confidential for environment '%s' should be '%v', was '%v'", env.inputName,
				env.expectedConfidential, got.Confidential)
		}
	}
}

var endpointTests = []struct {
	envName               string
	expectedTokenEndpoint string
	expectedDocumentAPI   string
}{
	{
		"dev",
		"https://sv-idp-keycloak-dev.osapps.peax.ch/auth/realms/peax-id-dev/peaxtoken",
		"https://sv-oauth-proxy-dev.osapps.peax.ch/document/api/v3",
	},
	{
		"devpatch",
		"https://sv-idp-keycloak-devpatch.osapps.peax.ch/auth/realms/peax-id-devpatch/peaxtoken",
		"https://sv-oauth-proxy-devpatch.osapps.peax.ch/document/api/v3",
	},
	{
		"test",
		"https://sv-idp-keycloak-test.osapps.peax.ch/auth/realms/peax-id-test/peaxtoken",
		"https://sv-oauth-proxy-test.osapps.peax.ch/document/api/v3",
	},
	{
		"testpatch",
		"https://sv-idp-keycloak-testpatch.osapps.peax.ch/auth/realms/peax-id-testpatch/peaxtoken",
		"https://sv-oauth-proxy-testpatch.osapps.peax.ch/document/api/v3",
	},
	{
		"stage",
		"https://sv-idp-keycloak-stage.osapps.peax.ch/auth/realms/peax-id-stage/peaxtoken",
		"https://sv-oauth-proxy-stage.osapps.peax.ch/document/api/v3",
	},
	{
		"prod",
		"https://idp.peax.ch/auth/realms/peax-id-prod/peaxtoken",
		"https://sv-oauth-proxy-prod.osapps.peax.ch/document/api/v3",
	},
	{
		"perf",
		"https://sv-idp-keycloak-perf.osapps.peax.ch/auth/realms/peax-id-perf/peaxtoken",
		"https://sv-oauth-proxy-perf.osapps.peax.ch/document/api/v3",
	},
	{
		"prototype",
		"https://sv-idp-keycloak-prototype.osapps.peax.ch/auth/realms/peax-id-prototype/peaxtoken",
		"https://sv-oauth-proxy-prototype.osapps.peax.ch/document/api/v3",
	},
}

func TestTokenEndpoint(t *testing.T) {
	for _, test := range endpointTests {
		env, err := GetEnvironment(test.envName)
		if err != nil {
			t.Errorf("GetEnvironment(%s) returned unexpected error: %v", test.envName, err)
			continue
		}
		if gotTokenEndpoint := env.TokenEndpoint(); gotTokenEndpoint != test.expectedTokenEndpoint {
			t.Errorf("token endpoint for environment '%s' should be '%s', was '%s'",
				test.envName, test.expectedTokenEndpoint, gotTokenEndpoint)
			continue
		}
		if gotDocumentAPI := env.DocumentAPI(); gotDocumentAPI != test.expectedDocumentAPI {
			t.Errorf("document API for environment '%s' should be '%s', was '%s'",
				test.envName, test.expectedDocumentAPI, gotDocumentAPI)
			continue
		}
	}
}

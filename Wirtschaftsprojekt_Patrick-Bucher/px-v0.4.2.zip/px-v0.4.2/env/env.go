// Package env describes the PEAX environments that can be used from px.
package env

import "fmt"

const (
	proxyURL = "sv-oauth-proxy-%s.osapps.peax.ch"
	idpURL   = "sv-idp-keycloak-%s.osapps.peax.ch"
)

var environmentNames = []string{
	"dev",
	"devpatch",
	"test",
	"testpatch",
	"stage",
	"prod",
	"perf",
	"prototype",
}

// Environment describes a PEAX environment with URLs (to proxy server and
// identity provider) and other attributes.
type Environment struct {
	Name         string
	Proxy        string
	IDP          string
	Realm        string
	Confidential bool
}

// Environments maps the environment's names to their environment
// configuration.
var Environments = map[string]Environment{}

func init() {
	for _, env := range environmentNames {
		proxy := fmt.Sprintf(proxyURL, env)
		idp := fmt.Sprintf(idpURL, env)
		confidential := false
		if env == "prod" {
			idp = "idp.peax.ch"
			confidential = true
		}
		Environments[env] = Environment{
			Name:         env,
			Proxy:        proxy,
			IDP:          idp,
			Realm:        fmt.Sprintf("peax-id-" + env),
			Confidential: confidential,
		}
	}
}

// GetEnvironment returns the environment configuration by its name.
func GetEnvironment(name string) (*Environment, error) {
	if env, ok := Environments[name]; ok {
		return &env, nil
	}
	return nil, fmt.Errorf("environment '%s' does not exist", name)
}

// TokenEndpoint returns the URL to the environment's token endpoint, pointing
// to its identity provider.
func (e *Environment) TokenEndpoint() string {
	return fmt.Sprintf("https://%s/auth/realms/%s/peaxtoken", e.IDP, e.Realm)
}

// DocumentAPI returns the URL to the environment's document API base URL.
func (e *Environment) DocumentAPI() string {
	return fmt.Sprintf("https://%s/document/api/v3", e.Proxy)
}

// ProxyURL returns the URL to the environment's proxy server.
func (e *Environment) ProxyURL(path string) string {
	return fmt.Sprintf("https://%s/%s", e.Proxy, path)
}

// AgentAPI returns the URL to the environment's Agent API base URL for the
// given area of the API (document, profile etc.).
func (e *Environment) AgentAPI(area string) string {
	return fmt.Sprintf("https://%s/%s/agent-api/v1", e.Proxy, area)
}

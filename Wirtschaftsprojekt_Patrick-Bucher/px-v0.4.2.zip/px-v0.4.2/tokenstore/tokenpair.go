package tokenstore

import (
	"encoding/base64"
	"encoding/json"
	"fmt"
	"strings"
	"time"

	"github.com/zalando/go-keyring"
)

// TokenType represents a string used internally to distinguish user tokens
// (obtained with username/password) and agent tokens (obtained using client
// credentials).
type TokenType string

const (
	// TokenTypeUser is a token for the User API.
	TokenTypeUser TokenType = "user"

	// TokenTypeAgent is a token for the Agent API.
	TokenTypeAgent TokenType = "agent"

	defaultClientID = "peax.portal"
)

// TokenPair is the data structure used internally to store access and refresh
// tokens. Additional context information is either added from the login
// context (environment, keystore to be used, type of the token) or extracted
// from the token pair for convenience (Peax ID, expiry information).
type TokenPair struct {
	AccessToken         string     `json:"access_token,omitempty"`
	AccessTokenExpires  *time.Time `json:"access_token_expires,omitempty"`
	RefreshToken        string     `json:"refresh_token,omitempty"`
	RefreshTokenExpires *time.Time `json:"refresh_token_expires,omitempty"`
	PeaxID              string     `json:"peax_id,omitempty"`
	ClientID            string     `json:"client_id,omitempty"`
	Environment         string     `json:"environment"`
	UseKeystore         bool       `json:"use_keystore"`
	Type                TokenType  `json:"token_type"`
}

// FromResponse creates a new TokenPair based on the TokenResponse returned
// from the IDP, with tokenType indicating if the token should be stored for
// user or agent operations.
func FromResponse(res *TokenResponse, environment string, tokenType TokenType) (*TokenPair, error) {
	now := time.Now()
	accessTokenExpires := now.Add(time.Duration(res.AccessTokenExpires) * time.Second)
	refreshTokenExpires := now.Add(time.Duration(res.RefreshTokenExpires) * time.Second)
	tokenPair := &TokenPair{
		AccessToken:         res.AccessToken,
		RefreshToken:        res.RefreshToken,
		AccessTokenExpires:  &accessTokenExpires,
		RefreshTokenExpires: &refreshTokenExpires,
		Environment:         environment,
		Type:                tokenType,
		ClientID:            defaultClientID,
	}
	peaxID, err := extractPeaxID(tokenPair.AccessToken)
	if err != nil {
		return nil, fmt.Errorf("set PEAX ID: %v", err)
	}
	tokenPair.PeaxID = peaxID
	tokenPair.ClientID = extractClientID(tokenPair.AccessToken)

	return tokenPair, nil
}

// IsAccessTokenAlive checks if the access token of the underlying token pair
// is not expired yet.
func (t *TokenPair) IsAccessTokenAlive() bool {
	return time.Now().Before(*t.AccessTokenExpires)
}

// IsRefreshTokenAlive checks if the access token of the underlying token pair
// is not expired yet.
func (t *TokenPair) IsRefreshTokenAlive() bool {
	return time.Now().Before(*t.RefreshTokenExpires)
}

// HasSecretTokens checks if there is a secretly stored token pair for the
// given type and environment in the operating system's key store.
func HasSecretTokens(environment string, tokenType TokenType) bool {
	_, err := loadSafely(environment, tokenType)
	return err == nil
}

func (t *TokenPair) storeSafely() error {
	accessTokenKey, refreshTokenKey := tokenKeys(t.Environment, t.Type)
	if err := storeSecret(accessTokenKey, "px", t.AccessToken); err != nil {
		return fmt.Errorf("store access token: %v", err)
	}
	if err := storeSecret(refreshTokenKey, "px", t.RefreshToken); err != nil {
		return fmt.Errorf("store refresh token: %v", err)
	}
	return nil
}

func loadSafely(environment string, tokenType TokenType) (*TokenPair, error) {
	accessTokenKey, refreshTokenKey := tokenKeys(environment, tokenType)
	accessToken, err := loadSecret(accessTokenKey, "px")
	if err != nil {
		return nil, fmt.Errorf("load access token: %v", err)
	}
	refreshToken, err := loadSecret(refreshTokenKey, "px")
	if err != nil {
		return nil, fmt.Errorf("load refresh token: %v", err)
	}
	peaxID, err := extractPeaxID(accessToken)
	if err != nil {
		return nil, fmt.Errorf("extract PEAX ID from access token: %v", err)
	}
	clientID := extractClientID(accessToken)
	tokens := TokenPair{
		AccessToken:  accessToken,
		RefreshToken: refreshToken,
		PeaxID:       peaxID,
		UseKeystore:  true,
		Environment:  environment,
		Type:         tokenType,
		ClientID:     clientID,
	}
	return &tokens, nil
}

func (t *TokenPair) forgetSafely() error {
	accessTokenKey, refreshTokenKey := tokenKeys(t.Environment, t.Type)
	if err := deleteSecret(accessTokenKey, "px"); err != nil {
		return fmt.Errorf("forget access token: %v", err)
	}
	if err := deleteSecret(refreshTokenKey, "px"); err != nil {
		return fmt.Errorf("forget refresh token: %v", err)
	}
	return nil
}

func extractPeaxID(accessToken string) (string, error) {
	jwtPayload, err := unmarshal(accessToken)
	if err != nil {
		return "", fmt.Errorf("extract PEAX ID from access token: %v", err)
	}
	return (*jwtPayload).PeaxID, nil
}

func extractClientID(accessToken string) string {
	jwtPayload, err := unmarshal(accessToken)
	if err != nil {
		return defaultClientID
	}
	clientID := (*jwtPayload).ClientID
	if strings.TrimSpace(clientID) == "" {
		clientID = defaultClientID
	}
	return clientID
}

func unmarshal(accessToken string) (*JWTPayload, error) {
	parts := strings.Split(accessToken, ".")
	if len(parts) != 3 {
		return nil, fmt.Errorf("splitting access token by '.': expected 3 parts, got %d", len(parts))
	}
	payload := parts[1] // 0: header, 1: payload, 2: signature
	data, err := base64.RawURLEncoding.DecodeString(payload)
	if err != nil {
		return nil, fmt.Errorf("base64 decode access token: %v", err)
	}
	var jwtPayload JWTPayload
	if err := json.Unmarshal(data, &jwtPayload); err != nil {
		return nil, fmt.Errorf("unmarshal %s: %v", string(data), err)
	}
	return &jwtPayload, nil
}

func storeSecret(key, username, password string) error {
	if err := keyring.Set(key, username, password); err != nil {
		return fmt.Errorf("store password for username %s on %s: %v", username, key, err)
	}
	return nil
}

func loadSecret(key, username string) (string, error) {
	password, err := keyring.Get(key, username)
	if err != nil {
		return "", fmt.Errorf("load secret for username %s on %s: %v", username, key, err)
	}
	return password, nil
}

func deleteSecret(key, username string) error {
	if err := keyring.Delete(key, username); err != nil {
		return fmt.Errorf("delete secret for username %s on %s: %v", username, key, err)
	}
	return nil
}

func tokenKeys(environment string, tokenType TokenType) (string, string) {
	accessTokenKey := fmt.Sprintf("px:%s:%s:accessToken", environment, tokenType)
	refreshTokenKey := fmt.Sprintf("px:%s:%s:refreshToken", environment, tokenType)
	return accessTokenKey, refreshTokenKey
}

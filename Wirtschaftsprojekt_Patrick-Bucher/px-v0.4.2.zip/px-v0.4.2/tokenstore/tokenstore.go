// Package tokenstore manages token pairs in the local storage.
package tokenstore

import (
	"encoding/json"
	"fmt"
	"px/utils"
	"time"
)

// DefaultTokenStoreFileName is the file name used to store token information.
const DefaultTokenStoreFileName = ".px-tokens"

// TokenKey is a string describing the context information of a token, being
// used as the key in the internal key store data structure, which is
// implemented as a map.
type TokenKey string

// InitTokenStore builds up an empty token store, if there's not already one in
// the user's home directory.
func InitTokenStore() error {
	tokenStoreFilePath, err := utils.GetHomeFolderPath(DefaultTokenStoreFileName)
	if err != nil {
		return err
	}
	if utils.FileMissing(tokenStoreFilePath) {
		now := time.Now()
		tokenStore := TokenStore{Tokens: map[TokenKey]TokenPair{}, Initialized: now}
		if err := tokenStore.WriteToJSONFile(DefaultTokenStoreFileName); err != nil {
			return err
		}
	}
	return nil
}

// TokenStore is the internal data structure to store token pairs. It contains
// the token pairs and meta information.
type TokenStore struct {
	// Tokens stores a TokenPair for every TokenKey, the latter consisting of
	// the environment name and a token type. With this key structure, only one
	// token pair can be stored for a combination of environment and token type
	// at any time.
	Tokens map[TokenKey]TokenPair `json:"tokens"`

	// DefaultEnvironment is the environment to be used for requests if there's
	// no other environment specified for the respective operation.
	DefaultEnvironment string `json:"default_environment,omitempty"`

	// Initialized is a timestamp representing the point in time when the token
	// store was initially created.
	Initialized time.Time `json:"initialized,omitempty"`
}

// EmptyTokenStore sets up a new token store with the current initialization
// timestamp.
func EmptyTokenStore() *TokenStore {
	emptyTokenStore := TokenStore{
		Tokens:             make(map[TokenKey]TokenPair),
		DefaultEnvironment: "",
		Initialized:        time.Now(),
	}
	return &emptyTokenStore
}

// ReadFromJSONFile reads and unmarshals the file at the absolute path
// jsonFilePath into a TokenStore, which is returned.
func ReadFromJSONFile(jsonFilePath string) (*TokenStore, error) {
	var tokenStore TokenStore
	content, err := utils.ReadFileFromHomeFolder(jsonFilePath)
	if err != nil {
		return nil, fmt.Errorf("read token store: %v", err)
	}
	if err := json.Unmarshal(content, &tokenStore); err != nil {
		return nil, fmt.Errorf("unmarshal dot file: %v", err)
	}
	return &tokenStore, nil
}

// WriteToJSONFile marshals and writes the TokenStore as a JSON file under
// jsonFilePath.
func (t *TokenStore) WriteToJSONFile(jsonFilePath string) error {
	if err := utils.WriteJSONFileToHomeFolder(t, jsonFilePath); err != nil {
		return fmt.Errorf("write token store: %v", err)
	}
	return nil
}

// GetTokenPair returns the stored TokenPair indicated with environment and
// token type. An error is returned if no matching token pair is available.
func (t *TokenStore) GetTokenPair(environment string, tokenType TokenType) (*TokenPair, error) {
	tokenPair, ok := t.Tokens[tokenKey(environment, tokenType)]
	if !ok {
		return nil, fmt.Errorf("no token pair available for environment '%s'", environment)
	}
	if tokenPair.UseKeystore {
		tokenPair, err := loadSafely(environment, tokenType)
		if err != nil {
			return nil, fmt.Errorf("unable to safely load token pair for environment '%s'", environment)
		}
		return tokenPair, nil
	}
	return &tokenPair, nil
}

// SaveTokenPair stores the given TokenPair in the TokenStore. If the
// UseKeystore flag is set to true, the operating system's secure key store is
// used to store the TokenPair, with a dummy entry in the TokenStore data
// structure indicating that the TokenPair is to be found in that key store.
func (t *TokenStore) SaveTokenPair(tokenPair *TokenPair) error {
	key := tokenKey(tokenPair.Environment, tokenPair.Type)
	if tokenPair.UseKeystore {
		if err := tokenPair.storeSafely(); err != nil {
			return fmt.Errorf("store token safely: %v", err)
		}
		// hint to secret store
		var dummy TokenPair
		dummy.UseKeystore = true
		dummy.Environment = tokenPair.Environment
		dummy.Type = tokenPair.Type
		dummy.ClientID = tokenPair.ClientID
		t.Tokens[key] = dummy
	} else {
		t.Tokens[key] = *tokenPair
	}
	return nil
}

// RemoveTokenPair removes the token pair for the given environment and
// TokenType both from the TokenStore data structure, and from the operating
// system's native key store, if it is stored there.
func (t *TokenStore) RemoveTokenPair(environment string, tokenType TokenType) error {
	tokenPair, err := t.GetTokenPair(environment, tokenType)
	if err != nil {
		return fmt.Errorf("unable to get token pair: %v", err)
	}
	if tokenPair.UseKeystore {
		err := tokenPair.forgetSafely()
		if err != nil {
			return fmt.Errorf("remove %s token pair of environment %s from key store: %v", tokenType, environment, err)
		}
	}
	key := tokenKey(environment, tokenType)
	if _, exists := t.Tokens[key]; !exists {
		return fmt.Errorf("remove token with key: lookup with key %s failed", key)
	}
	delete(t.Tokens, key)
	return nil
}

// RemoveAllTokenPairs flushes the TokenStore. Every single token is deleted,
// also if it is stored in the operating system's native key store.
func (t *TokenStore) RemoveAllTokenPairs(tokenType TokenType) error {
	for _, tokenPair := range t.Tokens {
		if tokenPair.Type != tokenType {
			continue
		}
		err := t.RemoveTokenPair(tokenPair.Environment, tokenType)
		if err != nil {
			return fmt.Errorf("remove all tokens: %v", err)
		}
	}
	return nil
}

func tokenKey(environment string, tokenType TokenType) TokenKey {
	return TokenKey(fmt.Sprintf("%s_%s", tokenType, environment))
}

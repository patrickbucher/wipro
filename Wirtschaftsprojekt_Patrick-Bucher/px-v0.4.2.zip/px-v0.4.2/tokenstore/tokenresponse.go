package tokenstore

// TokenResponse describes the response from to token endpoint, being returned
// after a authentication attempt.
type TokenResponse struct {
	AccessToken         string `json:"access_token"`
	AccessTokenExpires  uint   `json:"expires_in"`
	RefreshToken        string `json:"refresh_token"`
	RefreshTokenExpires uint   `json:"refresh_expires_in"`
}

// JWTPayload describes a payload containing a PEAX ID.
type JWTPayload struct {
	PeaxID   string `json:"peax_id"`
	ClientID string `json:"clientId"`
}

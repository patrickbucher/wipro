package tokenstore

import (
	"testing"
	"time"
)

var future = time.Now().Add(1 * time.Hour)
var past = time.Now().Add(-1 * time.Hour)

var tokenPairAliveTests = []struct {
	tokens            TokenPair
	accessTokenAlive  bool
	refreshTokenAlive bool
}{
	{
		tokens: TokenPair{
			AccessToken:         "first",
			RefreshToken:        "first",
			AccessTokenExpires:  &future,
			RefreshTokenExpires: &past,
		},
		accessTokenAlive:  true,
		refreshTokenAlive: false,
	}, {
		tokens: TokenPair{
			AccessToken:         "second",
			RefreshToken:        "second",
			AccessTokenExpires:  &past,
			RefreshTokenExpires: &future,
		},
		accessTokenAlive:  false,
		refreshTokenAlive: true,
	},
}

func TestTokenPairAlive(t *testing.T) {
	for _, test := range tokenPairAliveTests {
		accessTokenAlive := test.tokens.IsAccessTokenAlive()
		refreshTokenAlive := test.tokens.IsRefreshTokenAlive()
		if accessTokenAlive != test.accessTokenAlive {
			t.Errorf("access token %s alive: expected %v, got %v",
				test.tokens.AccessToken, test.accessTokenAlive, accessTokenAlive)
		}
		if refreshTokenAlive != test.refreshTokenAlive {
			t.Errorf("refresh token %s alive: expected %v, got %v",
				test.tokens.RefreshToken, test.refreshTokenAlive, refreshTokenAlive)
		}
	}
}
